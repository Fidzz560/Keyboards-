package com.example.mykeyboard

object Layouts {
    val digits = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")
    val hint2 = listOf("@", "#", "\$", "_", "&", "-", "+", "(", ")", "/")
    val hint3 = listOf("*", "\"", "'", ":", ";", "!", "?")

    private fun r(s: String) = s.map { it.toString() }

    fun letters(name: String): List<List<String>> = when (name) {
        "qwertz" -> listOf(r("qwertzuiop"), r("asdfghjkl"), r("yxcvbnm"))
        "azerty" -> listOf(r("azertyuiop"), r("qsdfghjklm"), r("wxcvbn"))
        "colemak" -> listOf(r("qwfpgjluy;"), r("arstdhneio"), r("zxcvbkm"))
        else -> listOf(r("qwertyuiop"), r("asdfghjkl"), r("zxcvbnm"))
    }

    // Baris terakhir selalu 7 karakter (diapit tombol pindah halaman & hapus)
    fun symbols(page: Int, numRow: Boolean): List<List<String>> {
        val a1 = listOf("@", "#", "\$", "_", "&", "-", "+", "(", ")", "/")
        val b1 = listOf("%", "<", ">", "[", "]", "{", "}", "=", "^", "~")
        val c1 = hint3
        val a2 = r("`|\\•√π÷×¶∆")
        val b2 = r("£¢€¥°©®™✓§")
        val x2 = r("←↑→↓★♥♪☺¿¡")
        val c2 = r("«»…‰µ¬±")
        return if (page == 1) {
            if (numRow) listOf(digits, a1, b1, c1) else listOf(digits, a1, c1)
        } else {
            if (numRow) listOf(a2, b2, x2, c2) else listOf(b1, b2, c2)
        }
    }
}

object EmojiData {
    val cats: List<Pair<String, List<String>>> = listOf(
        "😀" to ("😀 😃 😄 😁 😆 😅 😂 🤣 🙂 😉 😊 😇 🥰 😍 🤩 😘 😋 😛 😜 🤪 😎 🤓 🥳 😏 😒 😞 😔 😟 😕 🙁 😣 😢 😭 😤 😠 😡 🤯 😳 🥵 🥶 😱 😰 🤗 🤔 🤭 🤫 😶 😐 🙄 😬 😴 🤤 😷 🤒 🤕 🤢 🤮 🥴 😈 💀 👻 🤖").split(" "),
        "👍" to ("👍 👎 👌 🤞 🤟 🤘 🤙 👈 👉 👆 👇 ✋ 🤚 🖖 👋 👏 🙌 🤝 🙏 💪 🤳 👀 👅 👄 🧠 🙈 🙉 🙊 🕺 💃 🚶 🏃").split(" "),
        "💖" to ("\u2764\uFE0F 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 💕 💞 💓 💗 💖 💘 💝 ✨ ⭐ 🌟 💫 🔥 💥 💯 ✅ ❌ ❓ ❗ 🎉 🎊 🎁 🏆").split(" "),
        "🐶" to ("🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🐔 🐧 🐦 🦆 🦉 🐴 🦄 🐝 🦋 🐢 🐍 🐙 🐬 🐳 🌸 🌹 🌻 🌲 🍎 🍌 🍉 🍇 🍓 🍒 🍕 🍔 🍟 🌭 🍿 🍜 🍣 🍩 🍪 🎂 ☕ 🍺 🥤").split(" "),
        "📱" to ("📱 💻 📷 🎧 🎮 ⚽ 🏀 🎵 🎤 📚 📌 📎 🔑 🔒 💡 💰 💳 🚗 🚕 🚀 ⏰ 🏠 🌍 🌙 ⚡ 🌈 ⛄").split(" ")
    )
}
