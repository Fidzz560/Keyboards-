package com.example.mykeyboard

class Suggestions(private val prefs: Prefs) {
    private val base: List<String> = BASE.split(" ").filter { it.length > 1 }.distinct()

    fun suggest(w: String): List<String> {
        val p = w.lowercase()
        val learned = prefs.learned().filter { it.startsWith(p) && it != p }.sortedBy { it.length }
        val builtin = base.filter { it.startsWith(p) && it != p }
        val res = (learned + builtin).distinct().take(3)
        return if (res.isEmpty()) listOf(w) else res
    }

    fun learn(w: String) {
        if (w in base || !w.all { it.isLetter() || it == '\'' }) return
        prefs.addLearned(w)
    }

    companion object {
        const val BASE = "yang dan di ke dari untuk dengan ini itu tidak ada saya kamu aku kami kita mereka anda " +
            "akan sudah belum bisa mau sedang karena tetapi atau juga lebih sangat banyak semua apa siapa kapan " +
            "dimana bagaimana kenapa mengapa terima kasih selamat pagi siang sore malam maaf tolong silakan " +
            "besok kemarin hari sekarang nanti lagi masih pernah selalu kadang jangan harus boleh perlu ingin " +
            "makan minum tidur pergi pulang datang kerja belajar main baca tulis lihat dengar bicara beli jual " +
            "bayar kirim terima buka tutup cari tunggu bantu pakai ambil kasih tahu paham mengerti sebentar " +
            "sebelum sesudah setelah hanya sama dalam pada oleh bahwa jika kalau supaya agar sebagai antara " +
            "rumah teman keluarga sekolah kantor jalan kota negara waktu orang anak bapak ibu kakak adik " +
            "the and you that was for are with this have from they will would there their what about which " +
            "when your can said each she how other them then these some her make like him into time has look " +
            "more write see number way could people than first water been call who now find long down day did " +
            "get come made may part hello please thanks thank sorry good morning night today tomorrow yesterday " +
            "because but not just know take want think love friend work home phone message really maybe always " +
            "never later before after where why should going doing coming sure okay great nice welcome"
    }
}
