package com.example.mykeyboard

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import androidx.core.graphics.ColorUtils
import androidx.preference.PreferenceManager
import org.json.JSONArray

data class Palette(val bg: Int, val key: Int, val func: Int, val text: Int, val accent: Int, val pressed: Int)

class Prefs(ctx: Context) {
    val sp: SharedPreferences = PreferenceManager.getDefaultSharedPreferences(ctx)

    val layout get() = sp.getString("layout", "qwerty") ?: "qwerty"
    val theme get() = sp.getString("theme", "dark") ?: "dark"
    val numberRow get() = sp.getBoolean("number_row", true)
    val hints get() = sp.getBoolean("hints", true)
    val bold get() = sp.getBoolean("bold", false)
    val heightPercent get() = sp.getInt("height", 100)
    val textSize get() = sp.getInt("text_size", 20)
    val radius get() = sp.getInt("radius", 10)
    val gap get() = sp.getInt("gap", 3)
    val bottomPad get() = sp.getInt("bottom_pad", 0)
    val autoCap get() = sp.getBoolean("auto_cap", true)
    val suggestions get() = sp.getBoolean("suggestions", true)
    val doubleSpace get() = sp.getBoolean("double_space", true)
    val clipEnabled get() = sp.getBoolean("clip_enabled", true)
    val vibrate get() = sp.getBoolean("vibrate", true)
    val vibrateMs get() = sp.getInt("vibrate_ms", 15)
    val sound get() = sp.getBoolean("sound", false)

    private fun col(key: String, def: String): Int =
        try { Color.parseColor((sp.getString(key, def) ?: def).trim()) } catch (e: Exception) { Color.parseColor(def) }

    private fun mk(bg: Int, key: Int, func: Int, text: Int, accent: Int) =
        Palette(bg, key, func, text, accent, ColorUtils.blendARGB(key, accent, 0.35f))

    private fun pal(bg: String, key: String, func: String, text: String, accent: String) =
        mk(Color.parseColor(bg), Color.parseColor(key), Color.parseColor(func), Color.parseColor(text), Color.parseColor(accent))

    fun palette(): Palette = when (theme) {
        "light" -> pal("#D1D5DB", "#FFFFFF", "#B6BCC6", "#111111", "#1A73E8")
        "amoled" -> pal("#000000", "#121212", "#1E1E1E", "#FFFFFF", "#00E5FF")
        "ocean" -> pal("#0B2545", "#13315C", "#1C4A82", "#EEF4ED", "#8DA9C4")
        "sakura" -> pal("#FADADD", "#FFFFFF", "#F4B6C2", "#5B2333", "#E75480")
        "hacker" -> pal("#000000", "#0A140A", "#102010", "#33FF33", "#33FF33")
        "custom" -> mk(col("color_bg", "#202124"), col("color_key", "#3C4043"), col("color_func", "#2D2F31"),
            col("color_text", "#FFFFFF"), col("color_accent", "#8AB4F8"))
        else -> pal("#202124", "#3C4043", "#2D2F31", "#FFFFFF", "#8AB4F8")
    }

    // Clipboard history
    fun clips(): MutableList<String> {
        val out = mutableListOf<String>()
        try {
            val a = JSONArray(sp.getString("clips", "[]"))
            for (i in 0 until a.length()) out.add(a.getString(i))
        } catch (e: Exception) { }
        return out
    }

    private fun saveClips(l: List<String>) = sp.edit().putString("clips", JSONArray(l).toString()).apply()

    fun addClip(t: String) {
        val l = clips()
        l.remove(t)
        l.add(0, t)
        saveClips(l.take(30))
    }

    fun clearClips() = saveClips(emptyList())

    // Learned words
    fun learned(): Set<String> = sp.getStringSet("learned", emptySet()) ?: emptySet()

    fun addLearned(w: String) {
        val s = HashSet(learned())
        s.add(w)
        if (s.size > 800) s.remove(s.first())
        sp.edit().putStringSet("learned", s).apply()
    }
}
