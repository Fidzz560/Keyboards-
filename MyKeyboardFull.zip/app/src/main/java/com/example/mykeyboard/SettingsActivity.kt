package com.example.mykeyboard

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        findViewById<Button>(R.id.btnEnable).setOnClickListener {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }
        findViewById<Button>(R.id.btnPick).setOnClickListener {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction().replace(R.id.container, PrefsFragment()).commit()
        }
    }

    class PrefsFragment : PreferenceFragmentCompat() {
        override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
            setPreferencesFromResource(R.xml.preferences, rootKey)
            val p = Prefs(requireContext())
            fun act(key: String, msg: String, block: () -> Unit) {
                findPreference<Preference>(key)?.setOnPreferenceClickListener {
                    block()
                    Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show()
                    true
                }
            }
            act("clear_learned", "Kata yang dipelajari dihapus") { p.sp.edit().remove("learned").apply() }
            act("clear_clips", "Riwayat clipboard dihapus") { p.clearClips() }
            act("reset", "Pengaturan direset") {
                p.sp.edit().clear().apply()
                requireActivity().recreate()
            }
        }
    }
}
