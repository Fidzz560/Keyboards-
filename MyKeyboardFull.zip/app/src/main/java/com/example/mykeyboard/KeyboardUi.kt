package com.example.mykeyboard

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.graphics.ColorUtils
import kotlin.math.max

/** Satu tombol, digambar manual supaya ringan dan mudah dikustom. */
class KeyView(ctx: Context) : View(ctx) {
    var label = ""
    var hint: String? = null
    var fill = 0
    var fillPressed = 0
    var textColor = 0
    var hintColor = 0
    var radiusPx = 0f
    var textPx = 0f
    var gapPx = 0f
    var textScale = 1f
    var bold = false
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    override fun onDraw(c: Canvas) {
        rect.set(gapPx, gapPx, width - gapPx, height - gapPx)
        paint.style = Paint.Style.FILL
        paint.color = if (isPressed) fillPressed else fill
        c.drawRoundRect(rect, radiusPx, radiusPx, paint)
        paint.color = textColor
        paint.textAlign = Paint.Align.CENTER
        paint.isFakeBoldText = bold
        paint.textSize = textPx * textScale
        c.drawText(label, rect.centerX(), rect.centerY() - (paint.descent() + paint.ascent()) / 2, paint)
        hint?.let { h ->
            paint.isFakeBoldText = false
            paint.color = hintColor
            paint.textSize = textPx * 0.5f
            c.drawText(h, rect.right - textPx * 0.4f, rect.top + textPx * 0.75f, paint)
        }
    }
}

class KeyboardUi(private val s: KeyboardService) {
    private val d = s.resources.displayMetrics.density
    private fun dp(v: Float) = (v * d).toInt()

    val root = LinearLayout(s).apply { orientation = LinearLayout.VERTICAL }
    private val bar = LinearLayout(s)
    private val body = FrameLayout(s)
    private val sug = Array(3) { TextView(s) }
    private var lastSug: List<String> = emptyList()
    private var pal = s.prefs.palette()
    private var rowH = 0
    private var emojiCat = 0
    private val letterKeys = mutableListOf<KeyView>()
    private var shiftKey: KeyView? = null
    private val handler = Handler(Looper.getMainLooper())

    init {
        root.addView(bar)
        root.addView(body)
        rebuild()
    }

    fun rebuild() {
        val p = s.prefs
        pal = p.palette()
        rowH = dp(52f * p.heightPercent / 100f)
        root.setBackgroundColor(pal.bg)
        root.setPadding(0, 0, 0, dp(p.bottomPad.toFloat()))
        letterKeys.clear()
        shiftKey = null
        buildBar()
        body.removeAllViews()
        body.addView(
            when (s.panel) {
                Panel.EMOJI -> buildEmoji()
                Panel.CLIP -> buildClip()
                else -> buildKeys()
            }
        )
        refreshShift()
    }

    fun setSuggestions(l: List<String>) {
        lastSug = l
        sug.forEachIndexed { i, tv -> tv.text = l.getOrNull(i) ?: "" }
    }

    fun refreshShift() {
        val up = s.shift != 0
        letterKeys.forEach {
            val c = it.tag as String
            it.label = if (up) c.uppercase() else c
            it.invalidate()
        }
        shiftKey?.let {
            it.label = when (s.shift) { 0 -> "⇧"; 1 -> "⬆"; else -> "⇪" }
            it.fill = if (s.shift == 2) pal.accent else pal.func
            it.textColor = if (s.shift == 2) onAccent() else pal.text
            it.invalidate()
        }
    }

    private fun onAccent() = if (ColorUtils.calculateLuminance(pal.accent) > 0.5) Color.BLACK else Color.WHITE

    // ---------- Bar atas ----------
    private fun buildBar() {
        bar.removeAllViews()
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.layoutParams = LinearLayout.LayoutParams(-1, dp(40f))
        sug.forEachIndexed { i, tv ->
            tv.setTextColor(pal.text)
            tv.textSize = 16f
            tv.gravity = Gravity.CENTER
            tv.maxLines = 1
            tv.ellipsize = TextUtils.TruncateAt.END
            tv.text = lastSug.getOrNull(i) ?: ""
            tv.layoutParams = LinearLayout.LayoutParams(0, -1, 1f)
            tv.setOnClickListener {
                val t = tv.text.toString()
                if (t.isNotEmpty()) { s.feedback(); s.pickSuggestion(t) }
            }
            bar.addView(tv)
        }
        fun tool(label: String, action: () -> Unit) {
            val t = TextView(s)
            t.text = label
            t.textSize = 18f
            t.setTextColor(pal.text)
            t.gravity = Gravity.CENTER
            t.layoutParams = LinearLayout.LayoutParams(dp(42f), -1)
            t.setOnClickListener { s.feedback(); action() }
            bar.addView(t)
        }
        tool("😀") { s.openPanel(if (s.panel == Panel.EMOJI) Panel.KEYS else Panel.EMOJI) }
        tool("📋") { s.openPanel(if (s.panel == Panel.CLIP) Panel.KEYS else Panel.CLIP) }
        tool("⚙") {
            s.startActivity(Intent(s, SettingsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    // ---------- Pembuat tombol ----------
    private fun row() = LinearLayout(s).apply {
        orientation = LinearLayout.HORIZONTAL
        layoutParams = LinearLayout.LayoutParams(-1, rowH)
    }

    private fun spacer(w: Float) = View(s).apply { layoutParams = LinearLayout.LayoutParams(0, rowH, w) }

    private fun key(label: String, w: Float, func: Boolean = false, hint: String? = null): KeyView {
        val p = s.prefs
        val k = KeyView(s)
        k.layoutParams = LinearLayout.LayoutParams(0, rowH, w)
        k.label = label
        k.hint = if (p.hints) hint else null
        k.fill = if (func) pal.func else pal.key
        k.fillPressed = pal.pressed
        k.textColor = pal.text
        k.hintColor = ColorUtils.setAlphaComponent(pal.text, 140)
        k.radiusPx = dp(p.radius.toFloat()).toFloat()
        k.gapPx = dp(p.gap / 2f).toFloat()
        k.textPx = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, p.textSize.toFloat(), s.resources.displayMetrics)
        k.bold = p.bold
        if (label.codePointCount(0, label.length) > 1) k.textScale = 0.62f
        return k
    }

    private fun attach(v: KeyView, repeat: Boolean = false, onLong: (() -> Unit)? = null, onTap: () -> Unit) {
        var done = false
        val longRun = Runnable {
            done = true
            s.feedback()
            onLong?.invoke()
            v.isPressed = false
            v.invalidate()
        }
        val repRun = object : Runnable {
            override fun run() { onTap(); handler.postDelayed(this, 45) }
        }
        fun stop() { handler.removeCallbacks(longRun); handler.removeCallbacks(repRun) }
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    done = false
                    v.isPressed = true
                    v.invalidate()
                    s.feedback()
                    if (repeat) { onTap(); handler.postDelayed(repRun, 380) }
                    else if (onLong != null) handler.postDelayed(longRun, 330)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!done && (e.x < 0 || e.y < 0 || e.x > v.width || e.y > v.height)) {
                        done = true
                        stop()
                        v.isPressed = false
                        v.invalidate()
                    }
                }
                MotionEvent.ACTION_UP -> {
                    stop()
                    if (!repeat && !done) onTap()
                    v.isPressed = false
                    v.invalidate()
                }
                MotionEvent.ACTION_CANCEL -> {
                    stop()
                    v.isPressed = false
                    v.invalidate()
                }
            }
            true
        }
    }

    private fun charKey(c: String, w: Float, hint: String?): KeyView {
        val k = key(c, w, false, hint)
        if (c[0].isLetter()) { k.tag = c; letterKeys.add(k) }
        attach(k, onLong = hint?.let { h -> { s.typeLiteral(h) } }) { s.typeChar(c) }
        return k
    }

    private fun delKey(w: Float): KeyView {
        val k = key("⌫", w, true)
        attach(k, repeat = true) { s.backspace() }
        return k
    }

    private fun spaceKey(w: Float): KeyView {
        val k = key(if (s.mode == Mode.NUM) "space" else s.prefs.layout.uppercase(), w)
        k.textScale = 0.5f
        attach(k) { s.space() }
        return k
    }

    private fun enterKey(w: Float): KeyView {
        val k = key(s.enterLabel(), w, true)
        k.fill = pal.accent
        k.textColor = onAccent()
        attach(k) { s.enter() }
        return k
    }

    // ---------- Papan huruf / simbol / angka ----------
    private fun buildKeys(): View {
        val col = LinearLayout(s)
        col.orientation = LinearLayout.VERTICAL
        col.layoutParams = FrameLayout.LayoutParams(-1, -2)
        when (s.mode) {
            Mode.NUM -> numRows(col)
            Mode.LETTERS -> { letterRows(col); col.addView(bottomRow()) }
            else -> { symbolRows(col); col.addView(bottomRow()) }
        }
        return col
    }

    private fun letterRows(col: LinearLayout) {
        val p = s.prefs
        if (p.numberRow) {
            val r = row()
            Layouts.digits.forEach { r.addView(charKey(it, 1f, null)) }
            col.addView(r)
        }
        Layouts.letters(p.layout).forEachIndexed { i, chars ->
            val r = row()
            val n = chars.size
            val side = max(1f, (10 - n) / 2f)
            if (i == 1 && n < 10) r.addView(spacer((10 - n) / 2f))
            if (i == 2) {
                val sk = key("⇧", side, true)
                shiftKey = sk
                attach(sk) { s.toggleShift() }
                r.addView(sk)
            }
            chars.forEachIndexed { j, c ->
                val hint = when (i) {
                    0 -> if (!p.numberRow) Layouts.digits.getOrNull(j) else null
                    1 -> Layouts.hint2.getOrNull(j)
                    else -> Layouts.hint3.getOrNull(j)
                }
                r.addView(charKey(c, 1f, hint))
            }
            if (i == 1 && n < 10) r.addView(spacer((10 - n) / 2f))
            if (i == 2) r.addView(delKey(side))
            col.addView(r)
        }
    }

    private fun symbolRows(col: LinearLayout) {
        val page = if (s.mode == Mode.SYM1) 1 else 2
        val rows = Layouts.symbols(page, s.prefs.numberRow)
        rows.forEachIndexed { i, chars ->
            val r = row()
            val last = i == rows.size - 1
            if (last) {
                val t = key(if (page == 1) "=\\<" else "?123", 1.5f, true)
                attach(t) { s.setMode(if (page == 1) Mode.SYM2 else Mode.SYM1) }
                r.addView(t)
            }
            chars.forEach { r.addView(charKey(it, 1f, null)) }
            if (last) r.addView(delKey(1.5f))
            col.addView(r)
        }
    }

    private fun numRows(col: LinearLayout) {
        val sym4 = if (s.isPhone) "+" else "-"
        val spec = listOf(
            listOf("1", "2", "3", "DEL"), listOf("4", "5", "6", sym4),
            listOf("7", "8", "9", "."), listOf(",", "0", "SPACE", "ENTER")
        )
        spec.forEach { names ->
            val r = row()
            names.forEach { n ->
                r.addView(
                    when (n) {
                        "DEL" -> delKey(1f)
                        "SPACE" -> spaceKey(1f)
                        "ENTER" -> enterKey(1f)
                        else -> charKey(n, 1f, null)
                    }
                )
            }
            col.addView(r)
        }
    }

    private fun bottomRow(): LinearLayout {
        val r = row()
        val t = key(if (s.mode == Mode.LETTERS) "?123" else "ABC", 1.5f, true)
        attach(t) { s.toggleSymbols() }
        r.addView(t)
        val g = key("🌐", 1f, true)
        attach(g) { s.pickIme() }
        r.addView(g)
        val comma = key(",", 1f)
        attach(comma, onLong = { s.openPanel(Panel.EMOJI) }) { s.typeLiteral(",") }
        r.addView(comma)
        r.addView(spaceKey(4f))
        val dot = key(".", 1f)
        attach(dot) { s.typeLiteral(".") }
        r.addView(dot)
        r.addView(enterKey(1.5f))
        return r
    }

    // ---------- Panel emoji ----------
    private fun panelHeight() = rowH * (if (s.prefs.numberRow) 5 else 4)

    private fun panelBox(content: View, bottom: LinearLayout): View {
        val box = LinearLayout(s)
        box.orientation = LinearLayout.VERTICAL
        box.layoutParams = FrameLayout.LayoutParams(-1, panelHeight())
        content.layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
        box.addView(content)
        box.addView(bottom)
        return box
    }

    private fun backKey(): KeyView {
        val k = key("ABC", 1.5f, true)
        attach(k) { s.closePanel() }
        return k
    }

    private fun buildEmoji(): View {
        val scroll = ScrollView(s)
        val list = LinearLayout(s)
        list.orientation = LinearLayout.VERTICAL
        val perRow = 8
        EmojiData.cats[emojiCat].second.chunked(perRow).forEach { chunk ->
            val r = LinearLayout(s)
            r.orientation = LinearLayout.HORIZONTAL
            r.layoutParams = LinearLayout.LayoutParams(-1, (rowH * 0.9f).toInt())
            for (i in 0 until perRow) {
                val tv = TextView(s)
                tv.gravity = Gravity.CENTER
                tv.textSize = 24f
                tv.layoutParams = LinearLayout.LayoutParams(0, -1, 1f)
                chunk.getOrNull(i)?.let { e ->
                    tv.text = e
                    tv.setOnClickListener { s.feedback(); s.commitRaw(e) }
                }
                r.addView(tv)
            }
            list.addView(r)
        }
        scroll.addView(list)
        val bottom = row()
        bottom.addView(backKey())
        EmojiData.cats.forEachIndexed { i, c ->
            val k = key(c.first, 1f, i != emojiCat)
            k.textScale = 0.8f
            attach(k) { emojiCat = i; rebuild() }
            bottom.addView(k)
        }
        bottom.addView(delKey(1.5f))
        return panelBox(scroll, bottom)
    }

    // ---------- Panel clipboard ----------
    private fun buildClip(): View {
        val scroll = ScrollView(s)
        val list = LinearLayout(s)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(dp(8f), dp(4f), dp(8f), dp(4f))
        val clips = s.prefs.clips()
        if (clips.isEmpty()) {
            val tv = TextView(s)
            tv.text = "Belum ada riwayat clipboard.\nSalin teks, nanti muncul di sini."
            tv.setTextColor(pal.text)
            tv.gravity = Gravity.CENTER
            tv.setPadding(0, dp(24f), 0, 0)
            list.addView(tv)
        }
        clips.forEach { c ->
            val tv = TextView(s)
            tv.text = c
            tv.maxLines = 2
            tv.ellipsize = TextUtils.TruncateAt.END
            tv.setTextColor(pal.text)
            tv.textSize = 15f
            tv.setPadding(dp(12f), dp(10f), dp(12f), dp(10f))
            tv.background = GradientDrawable().apply {
                setColor(pal.key)
                cornerRadius = dp(s.prefs.radius.toFloat()).toFloat()
            }
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.setMargins(0, dp(3f), 0, dp(3f))
            tv.layoutParams = lp
            tv.setOnClickListener { s.feedback(); s.commitRaw(c) }
            list.addView(tv)
        }
        scroll.addView(list)
        val bottom = row()
        bottom.addView(backKey())
        val clear = key("Hapus semua", 3f, true)
        clear.textScale = 0.6f
        attach(clear) { s.prefs.clearClips(); rebuild() }
        bottom.addView(clear)
        bottom.addView(spacer(3.5f))
        bottom.addView(delKey(1.5f))
        return panelBox(scroll, bottom)
    }
}
