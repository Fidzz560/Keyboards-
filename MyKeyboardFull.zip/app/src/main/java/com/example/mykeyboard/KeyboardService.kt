package com.example.mykeyboard

import android.content.ClipboardManager
import android.content.Context
import android.inputmethodservice.InputMethodService
import android.media.AudioManager
import android.os.Build
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager

enum class Mode { LETTERS, SYM1, SYM2, NUM }
enum class Panel { KEYS, EMOJI, CLIP }

class KeyboardService : InputMethodService() {
    lateinit var prefs: Prefs
    private lateinit var dict: Suggestions
    private var ui: KeyboardUi? = null

    var shift = 0            // 0 mati, 1 sekali, 2 caps lock
    var mode = Mode.LETTERS
    var panel = Panel.KEYS
    var isPhone = false
    private var noSuggest = false
    private var lastSpace = 0L
    private var lastShiftTap = 0L

    private val vibrator by lazy { getSystemService(Context.VIBRATOR_SERVICE) as Vibrator }
    private val audio by lazy { getSystemService(Context.AUDIO_SERVICE) as AudioManager }

    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener {
        if (!prefs.clipEnabled) return@OnPrimaryClipChangedListener
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val sensitive = cm.primaryClipDescription?.extras?.getBoolean("android.content.extra.IS_SENSITIVE") ?: false
            if (sensitive) return@OnPrimaryClipChangedListener
            val t = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()?.trim()
            if (!t.isNullOrEmpty() && t.length < 2000) prefs.addClip(t)
        } catch (e: Exception) { }
    }

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        dict = Suggestions(prefs)
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).addPrimaryClipChangedListener(clipListener)
    }

    override fun onDestroy() {
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).removePrimaryClipChangedListener(clipListener)
        super.onDestroy()
    }

    override fun onEvaluateFullscreenMode() = false

    override fun onCreateInputView(): View {
        val u = KeyboardUi(this)
        ui = u
        return u.root
    }

    override fun onStartInputView(info: EditorInfo, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        val cls = info.inputType and InputType.TYPE_MASK_CLASS
        val v = info.inputType and InputType.TYPE_MASK_VARIATION
        isPhone = cls == InputType.TYPE_CLASS_PHONE
        noSuggest = cls != InputType.TYPE_CLASS_TEXT ||
            v == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
            v == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
            v == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
            v == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS ||
            v == InputType.TYPE_TEXT_VARIATION_URI ||
            (info.inputType and InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS) != 0
        mode = if (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE ||
            cls == InputType.TYPE_CLASS_DATETIME) Mode.NUM else Mode.LETTERS
        panel = Panel.KEYS
        shift = 0
        lastSpace = 0
        updateAutoCap()
        ui?.setSuggestions(emptyList())
        ui?.rebuild()
    }

    override fun onUpdateSelection(a: Int, b: Int, c: Int, d: Int, e: Int, f: Int) {
        super.onUpdateSelection(a, b, c, d, e, f)
        updateSuggestions()
    }

    // ---------- Umpan balik ----------
    @Suppress("DEPRECATION")
    fun feedback() {
        if (prefs.vibrate) {
            val ms = prefs.vibrateMs.toLong()
            if (Build.VERSION.SDK_INT >= 26) {
                vibrator.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
            } else vibrator.vibrate(ms)
        }
        if (prefs.sound) audio.playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD, 0.6f)
    }

    // ---------- Pengetikan ----------
    fun typeChar(c: String) {
        val out = if (c.isNotEmpty() && c[0].isLetter() && shift != 0) c.uppercase() else c
        commit(out)
    }

    fun typeLiteral(t: String) = commit(t)

    fun commitRaw(t: String) = commit(t)

    private fun commit(text: String) {
        val ic = currentInputConnection ?: return
        if (text.isNotEmpty() && !(text[0].isLetterOrDigit() || text[0] == '\'')) learnCurrentWord()
        ic.commitText(text, 1)
        if (shift == 1) shift = 0
        afterChange()
    }

    fun backspace() {
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)
        if (!sel.isNullOrEmpty()) ic.commitText("", 1) else ic.deleteSurroundingTextInCodePoints(1, 0)
        afterChange()
    }

    fun space() {
        val ic = currentInputConnection ?: return
        val now = SystemClock.uptimeMillis()
        if (prefs.doubleSpace && now - lastSpace < 400) {
            val before = ic.getTextBeforeCursor(2, 0)?.toString() ?: ""
            if (before.length == 2 && before[1] == ' ' && before[0].isLetterOrDigit()) {
                ic.deleteSurroundingText(1, 0)
                ic.commitText(". ", 1)
                lastSpace = 0
                afterChange()
                return
            }
        }
        lastSpace = now
        learnCurrentWord()
        ic.commitText(" ", 1)
        if (shift == 1) shift = 0
        afterChange()
    }

    fun enter() {
        val ic = currentInputConnection ?: return
        val info = currentInputEditorInfo
        val act = (info?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        val noAction = info == null ||
            (info.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0 ||
            act == EditorInfo.IME_ACTION_NONE || act == EditorInfo.IME_ACTION_UNSPECIFIED
        learnCurrentWord()
        if (noAction) sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER) else ic.performEditorAction(act)
        afterChange()
    }

    fun enterLabel(): String {
        val info = currentInputEditorInfo ?: return "⏎"
        if ((info.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0) return "⏎"
        return when (info.imeOptions and EditorInfo.IME_MASK_ACTION) {
            EditorInfo.IME_ACTION_GO -> "Go"
            EditorInfo.IME_ACTION_SEARCH -> "🔍"
            EditorInfo.IME_ACTION_SEND -> "Kirim"
            EditorInfo.IME_ACTION_NEXT -> "→"
            EditorInfo.IME_ACTION_DONE -> "✓"
            else -> "⏎"
        }
    }

    // ---------- Shift & mode ----------
    fun toggleShift() {
        val now = SystemClock.uptimeMillis()
        shift = if (now - lastShiftTap < 350 && shift == 1) 2 else if (shift == 0) 1 else 0
        lastShiftTap = now
        ui?.refreshShift()
    }

    private fun updateAutoCap() {
        if (shift == 2) return
        val ic = currentInputConnection
        val info = currentInputEditorInfo
        val caps = if (ic != null && info != null) ic.getCursorCapsMode(info.inputType) else 0
        shift = if (prefs.autoCap && mode == Mode.LETTERS && caps != 0) 1 else 0
    }

    fun toggleSymbols() {
        mode = if (mode == Mode.LETTERS) Mode.SYM1 else Mode.LETTERS
        panel = Panel.KEYS
        ui?.rebuild()
    }

    fun setMode(m: Mode) { mode = m; ui?.rebuild() }
    fun openPanel(p: Panel) { panel = p; ui?.rebuild() }
    fun closePanel() { panel = Panel.KEYS; ui?.rebuild() }

    fun pickIme() {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
    }

    // ---------- Saran kata ----------
    private fun currentWord(): String =
        currentInputConnection?.getTextBeforeCursor(30, 0)?.toString()
            ?.takeLastWhile { it.isLetter() || it == '\'' } ?: ""

    private fun learnCurrentWord() {
        if (noSuggest) return
        val w = currentWord()
        if (w.length >= 3) dict.learn(w.lowercase())
    }

    private fun updateSuggestions() {
        val u = ui ?: return
        if (!prefs.suggestions || noSuggest || mode != Mode.LETTERS) { u.setSuggestions(emptyList()); return }
        val w = currentWord()
        u.setSuggestions(if (w.isEmpty()) emptyList() else dict.suggest(w))
    }

    fun pickSuggestion(s: String) {
        val ic = currentInputConnection ?: return
        val w = currentWord()
        ic.deleteSurroundingText(w.length, 0)
        val out = if (w.firstOrNull()?.isUpperCase() == true) s.replaceFirstChar { it.uppercase() } else s
        ic.commitText("$out ", 1)
        if (out.length >= 3) dict.learn(out.lowercase())
        afterChange()
    }

    private fun afterChange() {
        updateAutoCap()
        ui?.refreshShift()
        updateSuggestions()
    }
}
