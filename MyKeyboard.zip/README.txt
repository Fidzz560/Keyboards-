MYKEYBOARD - cara pakai di AndroidIDE
=====================================
1. Di AndroidIDE: New Project -> Empty Activity (Kotlin, Views),
   Package name: com.example.mykeyboard, Min SDK 24.
2. Hapus MainActivity bawaan & layout activity_main.xml bawaan.
3. Salin isi folder app/src/main dari zip ini ke app/src/main proyekmu
   (timpa AndroidManifest.xml, res/values/themes.xml). Hapus themes.xml
   malam/night kalau ada (res/values-night/themes.xml).
4. Di app/build.gradle(.kts), pastikan dependencies berisi:
     implementation("androidx.core:core-ktx:1.12.0")
     implementation("androidx.appcompat:appcompat:1.6.1")
     implementation("androidx.preference:preference-ktx:1.2.1")
5. Sync, lalu Build -> Run / Build APK, pasang.
6. Buka aplikasi: tekan "1. Aktifkan" lalu nyalakan MyKeyboard,
   tekan "2. Pilih keyboard", dan pilih MyKeyboard.
