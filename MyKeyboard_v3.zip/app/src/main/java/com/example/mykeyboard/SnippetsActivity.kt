package com.example.mykeyboard

import android.os.Bundle
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/** Kelola teks cepat: kalimat yang sering diketik, bisa disisipkan langsung dari keyboard. */
class SnippetsActivity : AppCompatActivity() {
    private lateinit var p: Prefs
    private lateinit var list: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        p = Prefs(this)

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(12), dp(16), dp(28))
        val sc = ScrollView(this)
        sc.setBackgroundColor(Ui.BG)
        sc.addView(col)
        setContentView(sc)

        col.addView(tv(
            "Teks cepat menyimpan kalimat yang sering kamu ketik, misalnya alamat atau salam. " +
                "Di keyboard, buka menu lalu Teks cepat, dan ketuk isinya untuk langsung disisipkan.",
            13f, Ui.MUTED
        ))
        col.addView(actionButton("Tambah teks cepat") { addDialog() })
        col.addView(sectionTitle("Daftar"))
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        col.addView(list)
        render()
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    private fun render() {
        list.removeAllViews()
        val items = p.snippets()
        if (items.isEmpty()) {
            val empty = tv("Belum ada teks cepat.", 13f, Ui.MUTED)
            empty.gravity = Gravity.CENTER
            empty.setPadding(0, dp(28), 0, 0)
            list.addView(empty)
            return
        }
        items.forEachIndexed { i, sn ->
            val card = cardBox()
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL

            val texts = LinearLayout(this)
            texts.orientation = LinearLayout.VERTICAL
            texts.layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            val title = tv(sn.title, 15f, Ui.ACCENT, true)
            title.maxLines = 1
            title.ellipsize = TextUtils.TruncateAt.END
            val text = tv(sn.text, 13f, Ui.MUTED)
            text.maxLines = 2
            text.ellipsize = TextUtils.TruncateAt.END
            texts.addView(title)
            texts.addView(text)
            row.addView(texts)

            val del = IconView(this, Ic.TRASH, Ui.MUTED)
            del.layoutParams = LinearLayout.LayoutParams(dp(40), dp(40))
            del.bounce()
            del.setOnClickListener { confirmDelete(i, sn.title) }
            row.addView(del)

            card.addView(row)
            list.addView(card)
            card.enterAnim(i * 40L)
        }
    }

    private fun confirmDelete(i: Int, title: String) {
        AlertDialog.Builder(this)
            .setTitle("Hapus \"$title\"?")
            .setPositiveButton("Hapus") { _, _ ->
                p.removeSnippet(i)
                render()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun addDialog() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), 0)

        val nameField = EditText(this)
        nameField.hint = "Judul, misalnya: Alamat rumah"
        nameField.setSingleLine()
        val textField = EditText(this)
        textField.hint = "Isi yang akan disisipkan"
        textField.minLines = 2
        textField.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        box.addView(nameField)
        box.addView(textField)

        AlertDialog.Builder(this)
            .setTitle("Teks cepat baru")
            .setView(box)
            .setPositiveButton("Simpan", null)
            .setNegativeButton("Batal", null)
            .create()
            .also { dialog ->
                dialog.show()
                // Tombol Simpan diatur ulang agar dialog tetap terbuka bila isi kosong
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                    val title = nameField.text.toString().trim()
                    val value = textField.text.toString().trim()
                    if (title.isEmpty() || value.isEmpty()) {
                        Toast.makeText(this, "Judul dan isi harus diisi", Toast.LENGTH_SHORT).show()
                    } else {
                        p.addSnippet(title, value)
                        render()
                        dialog.dismiss()
                    }
                }
            }
    }
}
