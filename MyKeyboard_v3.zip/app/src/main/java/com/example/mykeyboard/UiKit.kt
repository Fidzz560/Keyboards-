package com.example.mykeyboard

import android.animation.ValueAnimator
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.core.graphics.ColorUtils
import kotlin.math.max
import kotlin.math.min

/** Warna tetap untuk layar aplikasi (tema gelap). */
object Ui {
    val BG = Color.parseColor("#14171F")
    val CARD = Color.parseColor("#1F2430")
    val STROKE = Color.parseColor("#2C3344")
    val TEXT = Color.WHITE
    val MUTED = Color.parseColor("#AAB0BF")
    val ACCENT = Color.parseColor("#8AB4F8")
    val OK = Color.parseColor("#7BD389")
    val BAD = Color.parseColor("#FF8A80")
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun hex(c: Int): String = String.format("#%06X", 0xFFFFFF and c)

fun Context.roundRect(color: Int, rDp: Int, stroke: Int = 0, strokeDp: Int = 0): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(color)
    g.cornerRadius = dp(rDp).toFloat()
    if (strokeDp > 0) g.setStroke(dp(strokeDp), stroke)
    return g
}

fun Context.tv(t: String, sp: Float = 14f, color: Int = Ui.TEXT, bold: Boolean = false): TextView {
    val v = TextView(this)
    v.text = t
    v.textSize = sp
    v.setTextColor(color)
    if (bold) v.setTypeface(v.typeface, Typeface.BOLD)
    return v
}

fun Context.sectionTitle(t: String): TextView {
    val v = tv(t.uppercase(), 11f, Ui.ACCENT, true)
    v.letterSpacing = 0.08f
    v.setPadding(dp(4), dp(20), 0, dp(8))
    return v
}

fun Context.cardBox(): LinearLayout {
    val c = LinearLayout(this)
    c.orientation = LinearLayout.VERTICAL
    c.setPadding(dp(16), dp(14), dp(16), dp(14))
    c.background = roundRect(Ui.CARD, 18, Ui.STROKE, 1)
    val lp = LinearLayout.LayoutParams(-1, -2)
    lp.topMargin = dp(10)
    c.layoutParams = lp
    return c
}

fun Context.actionButton(label: String, onClick: () -> Unit): TextView {
    val b = tv(label, 14f, Color.parseColor("#0B1B3A"), true)
    b.gravity = Gravity.CENTER
    b.setPadding(dp(14), dp(12), dp(14), dp(12))
    b.background = roundRect(Ui.ACCENT, 14)
    val lp = LinearLayout.LayoutParams(-1, -2)
    lp.topMargin = dp(12)
    b.layoutParams = lp
    b.bounce()
    b.setOnClickListener { onClick() }
    return b
}

/** Efek tekan: sedikit mengecil lalu memantul kembali. Klik tetap berjalan seperti biasa. */
fun View.bounce() {
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN ->
                v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(90L).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                v.animate().scaleX(1f).scaleY(1f).setDuration(280L)
                    .setInterpolator(OvershootInterpolator(1.4f)).start()
        }
        false
    }
}

/** Animasi masuk: naik sedikit sambil memudar, bisa diberi jeda agar tampil bertahap. */
fun View.enterAnim(delay: Long = 0L) {
    alpha = 0f
    translationY = context.dp(14).toFloat()
    animate().alpha(1f).translationY(0f).setStartDelay(delay).setDuration(420L)
        .setInterpolator(DecelerateInterpolator()).start()
}

/** Kotak ikon membulat untuk kartu dan header. */
fun Context.iconBadge(ic: Ic, color: Int, bg: Int, sizeDp: Int = 44): FrameLayout {
    val f = FrameLayout(this)
    f.background = roundRect(bg, sizeDp / 3)
    f.layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
    f.addView(IconView(this, ic, color), FrameLayout.LayoutParams(-1, -1))
    return f
}

/** Baris slider yang langsung menyimpan nilainya ke SharedPreferences. */
fun Context.sliderRow(
    title: String, sp: SharedPreferences, key: String, min: Int, max: Int, def: Int,
    unit: String = "", onChange: () -> Unit = {}
): View {
    val box = LinearLayout(this)
    box.orientation = LinearLayout.VERTICAL
    box.setPadding(0, dp(6), 0, dp(6))
    val head = LinearLayout(this)
    head.orientation = LinearLayout.HORIZONTAL
    val t = tv(title, 14f)
    t.layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
    val value = tv("", 14f, Ui.ACCENT, true)
    head.addView(t)
    head.addView(value)
    val sb = SeekBar(this)
    sb.max = max - min
    sb.progress = (sp.getInt(key, def) - min).coerceIn(0, max - min)
    value.text = "${sb.progress + min}$unit"
    sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
            value.text = "${p + min}$unit"
            if (fromUser) {
                sp.edit().putInt(key, p + min).apply()
                onChange()
            }
        }
        override fun onStartTrackingTouch(s: SeekBar?) {}
        override fun onStopTrackingTouch(s: SeekBar?) {}
    })
    box.addView(head)
    box.addView(sb)
    return box
}

/** Dialog pemilih warna: slider R/G/B + kode hex + pratinjau. */
fun Context.pickColor(title: String, initial: Int, onPick: (Int) -> Unit) {
    var cur = initial or (0xFF shl 24)
    var busy = false
    val box = LinearLayout(this)
    box.orientation = LinearLayout.VERTICAL
    box.setPadding(dp(20), dp(12), dp(20), 0)
    val prev = View(this)
    prev.layoutParams = LinearLayout.LayoutParams(-1, dp(56))
    val hexField = EditText(this)
    hexField.hint = "#RRGGBB"
    hexField.setSingleLine()
    val bars = ArrayList<SeekBar>()

    fun update(c: Int, setHex: Boolean) {
        busy = true
        cur = c or (0xFF shl 24)
        prev.background = roundRect(cur, 10)
        bars[0].progress = Color.red(cur)
        bars[1].progress = Color.green(cur)
        bars[2].progress = Color.blue(cur)
        if (setHex) hexField.setText(hex(cur))
        busy = false
    }

    box.addView(prev)
    listOf("R", "G", "B").forEach { n ->
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val l = tv(n, 14f, Ui.MUTED)
        l.layoutParams = LinearLayout.LayoutParams(dp(20), -2)
        val sb = SeekBar(this)
        sb.max = 255
        sb.layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (busy || !fromUser) return
                update(Color.rgb(bars[0].progress, bars[1].progress, bars[2].progress), true)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        bars.add(sb)
        row.addView(l)
        row.addView(sb)
        box.addView(row)
    }
    hexField.addTextChangedListener(object : TextWatcher {
        override fun afterTextChanged(e: Editable?) {
            if (busy) return
            val t = e?.toString()?.trim()?.removePrefix("#") ?: return
            if (t.length == 6) {
                try { update(Color.parseColor("#$t"), false) } catch (x: Exception) { }
            }
        }
        override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
    })
    box.addView(hexField)
    update(cur, true)
    AlertDialog.Builder(this)
        .setTitle(title)
        .setView(box)
        .setPositiveButton("Pilih") { _, _ -> onPick(cur) }
        .setNegativeButton("Batal", null)
        .show()
}

/** Pratinjau keyboard mini yang menggambar palet, bentuk tombol, dan latar. */
class ThemePreview(ctx: Context) : View(ctx) {
    /** Palet yang dituju. Mengganti langsung tanpa animasi; pakai [animatePal] untuk transisi. */
    var pal: Palette = Themes.list[0].pal
        set(v) {
            field = v
            from = null
            t = 1f
        }
    var radiusDp = 10f
    var gapDp = 3f
    var bitmap: Bitmap? = null
    var dimPct = 0
    var keyAlphaPct = 100
    private var from: Palette? = null
    private var t = 1f
    private var anim: ValueAnimator? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val src = Rect()
    private val dst = Rect()

    // type: 0 huruf, 1 fungsi, 2 aksen, 3 kosong
    private val rows: List<List<Pair<Float, Int>>> = listOf(
        List(10) { 1f to 0 },
        listOf(0.5f to 3) + List(9) { 1f to 0 } + listOf(0.5f to 3),
        listOf(1.5f to 1) + List(7) { 1f to 0 } + listOf(1.5f to 1),
        listOf(1.5f to 1, 1f to 1, 1f to 0, 4f to 0, 1f to 0, 1.5f to 2)
    )
    private val letters = "qwertyuiopasdfghjklzxcvbnm"

    /** Ganti palet dengan transisi warna yang halus. */
    fun animatePal(to: Palette) {
        if (to == pal) return
        val prev = shownPal()
        pal = to
        from = prev
        t = 0f
        anim?.cancel()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 320L
            addUpdateListener {
                t = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    /** Palet yang sedang tampil (campuran dari palet lama ke palet baru selama animasi). */
    private fun shownPal(): Palette {
        val f = from ?: return pal
        if (t >= 1f) return pal
        val b = pal
        return Palette(
            ColorUtils.blendARGB(f.bg, b.bg, t),
            ColorUtils.blendARGB(f.key, b.key, t),
            ColorUtils.blendARGB(f.func, b.func, t),
            ColorUtils.blendARGB(f.text, b.text, t),
            ColorUtils.blendARGB(f.accent, b.accent, t),
            ColorUtils.blendARGB(f.pressed, b.pressed, t)
        )
    }

    override fun onDraw(c: Canvas) {
        val cur = shownPal()
        val w = width.toFloat()
        val h = height.toFloat()
        val d = resources.displayMetrics.density
        val clip = Path()
        clip.addRoundRect(RectF(0f, 0f, w, h), 12 * d, 12 * d, Path.Direction.CW)
        c.save()
        c.clipPath(clip)
        paint.style = Paint.Style.FILL
        paint.color = cur.bg
        c.drawRect(0f, 0f, w, h, paint)
        val b = bitmap
        if (b != null) {
            val scale = max(w / b.width, h / b.height)
            val sw = w / scale
            val sh = h / scale
            src.set(((b.width - sw) / 2).toInt(), ((b.height - sh) / 2).toInt(),
                ((b.width + sw) / 2).toInt(), ((b.height + sh) / 2).toInt())
            dst.set(0, 0, width, height)
            c.drawBitmap(b, src, dst, paint)
            paint.color = Color.argb(dimPct * 255 / 100, 0, 0, 0)
            c.drawRect(0f, 0f, w, h, paint)
        }
        val pad = 6 * d
        val rh = (h - 2 * pad) / rows.size
        val k = rh / (52f * d)
        val g = gapDp / 2f * d * k
        val rr = min(radiusDp * d * k, rh / 2)
        var li = 0
        rows.forEachIndexed { ri, row ->
            val total = row.sumOf { it.first.toDouble() }.toFloat()
            var x = pad
            val y = pad + ri * rh
            row.forEach { (wt, type) ->
                val kw = (w - 2 * pad) * wt / total
                if (type != 3) {
                    var col = when (type) { 1 -> cur.func; 2 -> cur.accent; else -> cur.key }
                    if (b != null && type != 2) col = ColorUtils.setAlphaComponent(col, keyAlphaPct * 255 / 100)
                    paint.color = col
                    c.drawRoundRect(RectF(x + g, y + g, x + kw - g, y + rh - g), rr, rr, paint)
                    if (type == 0 && ri < 3 && li < letters.length) {
                        paint.color = cur.text
                        paint.textSize = rh * 0.42f
                        paint.textAlign = Paint.Align.CENTER
                        c.drawText(letters[li].toString(), x + kw / 2, y + rh / 2 - (paint.descent() + paint.ascent()) / 2, paint)
                        li++
                    }
                }
                x += kw
            }
        }
        c.restore()
    }
}
