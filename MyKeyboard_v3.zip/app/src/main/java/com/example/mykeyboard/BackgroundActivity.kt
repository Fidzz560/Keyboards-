package com.example.mykeyboard

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max

class BackgroundActivity : AppCompatActivity() {
    private lateinit var p: Prefs
    private lateinit var preview: ThemePreview
    private lateinit var status: TextView

    private val pickImage = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importImage(uri)
    }
    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importVideo(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        p = Prefs(this)
        val sc = ScrollView(this)
        sc.setBackgroundColor(Ui.BG)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(12), dp(16), dp(28))
        sc.addView(col)
        setContentView(sc)

        preview = ThemePreview(this)
        preview.layoutParams = LinearLayout.LayoutParams(-1, dp(170))
        col.addView(preview)
        status = tv("", 13f, Ui.MUTED)
        status.setPadding(dp(4), dp(8), 0, 0)
        col.addView(status)

        col.addView(sectionTitle("Pilih latar"))
        val box = cardBox()
        box.addView(actionButton("Pilih foto") { pickImage.launch(arrayOf("image/*")) })
        box.addView(actionButton("Pilih video") { pickVideo.launch(arrayOf("video/*")) })
        box.addView(actionButton("Hapus latar") { clearBg() })
        box.addView(tv(
            "Video diputar tanpa suara, mulai saat keyboard dibuka, berulang terus, dan berhenti saat keyboard ditutup. " +
                "Pakai video pendek (di bawah 30 detik) agar hemat baterai.", 12f, Ui.MUTED
        ).apply { setPadding(0, dp(10), 0, 0) })
        col.addView(box)

        col.addView(sectionTitle("Tampilan di atas latar"))
        val s2 = cardBox()
        s2.addView(sliderRow("Redupkan latar", p.sp, "bg_dim", 0, 90, 35, "%") { refreshPreview() })
        s2.addView(sliderRow("Opasitas tombol", p.sp, "key_alpha", 30, 100, 75, "%") { refreshPreview() })
        col.addView(s2)
        refreshPreview()
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun clearBg() {
        p.sp.edit().putString("bg_type", "none").apply()
        p.bgImageFile().delete()
        p.bgVideoFile().delete()
        toast("Latar dihapus")
        refreshPreview()
    }

    private fun refreshPreview() {
        val pal = p.palette()
        preview.pal = pal
        preview.radiusDp = p.radius.toFloat()
        preview.gapDp = p.gap.toFloat()
        preview.dimPct = p.bgDim
        preview.keyAlphaPct = p.keyAlpha
        val kind = p.bgKind()
        preview.bitmap = try {
            when (kind) {
                "image" -> BitmapFactory.decodeFile(p.bgImageFile().absolutePath, BitmapFactory.Options().apply { inSampleSize = 2 })
                "video" -> {
                    val r = MediaMetadataRetriever()
                    try {
                        r.setDataSource(p.bgVideoFile().absolutePath)
                        r.getFrameAtTime(0)
                    } finally {
                        r.release()
                    }
                }
                else -> null
            }
        } catch (e: Throwable) { null }
        preview.invalidate()
        status.text = when (kind) {
            "image" -> "Latar aktif: foto"
            "video" -> "Latar aktif: video"
            else -> "Belum ada latar. Pilih foto atau video."
        }
    }

    // ---------- Foto ----------
    private fun importImage(uri: Uri) {
        Thread {
            val ok = try {
                val bmp = decodeScaled(uri, 1600) ?: throw IllegalStateException("decode")
                val rot = exifRotation(uri)
                val out = if (rot != 0) {
                    val m = Matrix()
                    m.postRotate(rot.toFloat())
                    Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                } else bmp
                FileOutputStream(p.bgImageFile()).use { out.compress(Bitmap.CompressFormat.JPEG, 90, it) }
                true
            } catch (e: Throwable) { false }
            runOnUiThread {
                if (ok) {
                    p.sp.edit().putString("bg_type", "image").apply()
                    toast("Foto latar disimpan")
                } else toast("Gagal memuat foto")
                refreshPreview()
            }
        }.start()
    }

    private fun decodeScaled(uri: Uri, maxSide: Int): Bitmap? {
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var sample = 1
        while (max(o.outWidth, o.outHeight) / sample > maxSide) sample *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = sample
        return contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
    }

    private fun exifRotation(uri: Uri): Int = try {
        contentResolver.openInputStream(uri)?.use {
            when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90
                ExifInterface.ORIENTATION_ROTATE_180 -> 180
                ExifInterface.ORIENTATION_ROTATE_270 -> 270
                else -> 0
            }
        } ?: 0
    } catch (e: Throwable) { 0 }

    // ---------- Video ----------
    private fun importVideo(uri: Uri) {
        toast("Menyalin video...")
        Thread {
            val tmp = File(filesDir, "bg_video.tmp")
            val ok = try {
                var total = 0L
                contentResolver.openInputStream(uri)!!.use { input ->
                    FileOutputStream(tmp).use { output ->
                        val buf = ByteArray(64 * 1024)
                        var n = 0
                        while (input.read(buf).also { n = it } > 0) {
                            total += n
                            if (total > MAX_VIDEO) throw IllegalStateException("terlalu besar")
                            output.write(buf, 0, n)
                        }
                    }
                }
                val dest = p.bgVideoFile()
                if (dest.exists()) dest.delete()
                tmp.renameTo(dest)
            } catch (e: Throwable) {
                tmp.delete()
                false
            }
            runOnUiThread {
                if (ok) {
                    p.sp.edit().putString("bg_type", "video").apply()
                    toast("Video latar disimpan")
                } else toast("Gagal memuat video (maks 120 MB)")
                refreshPreview()
            }
        }.start()
    }

    companion object {
        private const val MAX_VIDEO = 120L * 1024 * 1024
    }
}
