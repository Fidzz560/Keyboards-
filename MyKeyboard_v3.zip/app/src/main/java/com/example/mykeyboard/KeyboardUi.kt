package com.example.mykeyboard

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.SurfaceTexture
import android.graphics.drawable.GradientDrawable
import android.animation.ValueAnimator
import android.graphics.Typeface
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewOutlineProvider
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.graphics.ColorUtils
import java.io.File
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Satu tombol, digambar manual. Saat ditekan mengecil dan berubah warna dengan animasi halus. */
class KeyView(ctx: Context) : View(ctx) {
    var label = ""
    var hint: String? = null
    var icon: Ic? = null
    var fill = 0
    var fillPressed = 0
    var textColor = 0
    var hintColor = 0
    var radiusPx = 0f
    var textPx = 0f
    var gapPx = 0f
    var textScale = 1f
    var bold = false
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private var pressT = 0f
    private var anim: ValueAnimator? = null

    override fun setPressed(pressed: Boolean) {
        val was = isPressed
        super.setPressed(pressed)
        if (was != pressed) {
            anim?.cancel()
            anim = ValueAnimator.ofFloat(pressT, if (pressed) 1f else 0f).apply {
                duration = if (pressed) 60L else 160L
                addUpdateListener {
                    pressT = it.animatedValue as Float
                    invalidate()
                }
                start()
            }
        }
    }

    override fun onDraw(c: Canvas) {
        val sc = 1f - 0.08f * pressT
        c.save()
        c.scale(sc, sc, width / 2f, height / 2f)
        rect.set(gapPx, gapPx, width - gapPx, height - gapPx)
        paint.style = Paint.Style.FILL
        paint.color = ColorUtils.blendARGB(fill, fillPressed, pressT)
        c.drawRoundRect(rect, radiusPx, radiusPx, paint)
        val ic = icon
        if (ic != null) {
            val sz = min(rect.width(), rect.height()) * 0.46f
            Icons.draw(c, ic, rect.centerX() - sz / 2f, rect.centerY() - sz / 2f, sz, textColor)
        } else {
            paint.color = textColor
            paint.textAlign = Paint.Align.CENTER
            paint.isFakeBoldText = bold
            paint.textSize = textPx * textScale
            c.drawText(label, rect.centerX(), rect.centerY() - (paint.descent() + paint.ascent()) / 2, paint)
        }
        hint?.let { h ->
            paint.isFakeBoldText = false
            paint.color = hintColor
            paint.textSize = textPx * 0.5f
            c.drawText(h, rect.right - textPx * 0.4f, rect.top + textPx * 0.75f, paint)
        }
        c.restore()
    }
}

/** Latar foto (center-crop). Tidak ikut menentukan tinggi keyboard. */
class BgImageView(ctx: Context) : View(ctx) {
    private var bmp: Bitmap? = null
    private var stamp = 0L
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val src = Rect()
    private val dst = Rect()

    fun load(f: File?) {
        if (f == null || !f.exists()) {
            bmp = null
            stamp = 0
            invalidate()
            return
        }
        val st = f.lastModified() + f.length()
        if (st == stamp && bmp != null) return
        stamp = st
        bmp = try { BitmapFactory.decodeFile(f.absolutePath) } catch (e: Throwable) { null }
        invalidate()
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(resolveSize(0, w), resolveSize(0, h))
    }

    override fun onDraw(c: Canvas) {
        val b = bmp ?: return
        val vw = width.toFloat()
        val vh = height.toFloat()
        val scale = max(vw / b.width, vh / b.height)
        val sw = vw / scale
        val sh = vh / scale
        src.set(((b.width - sw) / 2).toInt(), ((b.height - sh) / 2).toInt(),
            ((b.width + sw) / 2).toInt(), ((b.height + sh) / 2).toInt())
        dst.set(0, 0, width, height)
        c.drawBitmap(b, src, dst, paint)
    }
}

/** Latar video: tanpa suara, berulang, mulai saat start(), berhenti & dilepas saat stop(). */
class VideoBgView(ctx: Context) : TextureView(ctx), TextureView.SurfaceTextureListener {
    private var mp: MediaPlayer? = null
    private var surf: Surface? = null
    private var path: String? = null
    private var want = false
    private var vw = 0
    private var vh = 0

    init { surfaceTextureListener = this }

    fun setSource(p: String?) {
        if (p == path) return
        path = p
        release()
        if (p != null && want) tryStart()
    }

    fun start() {
        want = true
        tryStart()
    }

    fun stop() {
        want = false
        release()
    }

    private fun tryStart() {
        val f = path ?: return
        val st = surfaceTexture ?: return
        if (!want || mp != null || !isAvailable) return
        try {
            val m = MediaPlayer()
            mp = m
            val sf = Surface(st)
            surf = sf
            m.setDataSource(f)
            m.setSurface(sf)
            m.isLooping = true
            m.setVolume(0f, 0f)
            m.setOnVideoSizeChangedListener { _, w, h -> vw = w; vh = h; fit() }
            m.setOnPreparedListener { if (mp === it) it.start() }
            m.setOnErrorListener { _, _, _ -> release(); true }
            m.prepareAsync()
        } catch (e: Exception) {
            release()
        }
    }

    private fun release() {
        try { mp?.setOnPreparedListener(null); mp?.stop() } catch (e: Exception) { }
        try { mp?.release() } catch (e: Exception) { }
        mp = null
        try { surf?.release() } catch (e: Exception) { }
        surf = null
    }

    private fun fit() {
        if (vw == 0 || vh == 0 || width == 0 || height == 0) return
        val w = width.toFloat()
        val h = height.toFloat()
        val scale = max(w / vw, h / vh)
        val m = Matrix()
        m.setScale(vw * scale / w, vh * scale / h, w / 2, h / 2)
        setTransform(m)
    }

    override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) { tryStart() }
    override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) { fit() }
    override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean { release(); return true }
    override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(resolveSize(0, w), resolveSize(0, h))
    }
}

/** Kartu keyboard: anak terakhir = isi; anak lain (latar) mengikuti ukuran isi. */
class KeyboardCard(ctx: Context) : FrameLayout(ctx) {
    override fun onMeasure(w: Int, h: Int) {
        val content = getChildAt(childCount - 1)
        val hMode = MeasureSpec.getMode(h)
        val hs = MeasureSpec.makeMeasureSpec(
            MeasureSpec.getSize(h),
            if (hMode == MeasureSpec.UNSPECIFIED) MeasureSpec.UNSPECIFIED else MeasureSpec.AT_MOST
        )
        content.measure(w, hs)
        val cw = content.measuredWidth
        val ch = content.measuredHeight
        val width = if (MeasureSpec.getMode(w) == MeasureSpec.EXACTLY) MeasureSpec.getSize(w) else cw
        for (i in 0 until childCount - 1) {
            val c = getChildAt(i)
            if (c.visibility != View.GONE) {
                c.measure(
                    MeasureSpec.makeMeasureSpec(width, MeasureSpec.EXACTLY),
                    MeasureSpec.makeMeasureSpec(ch, MeasureSpec.EXACTLY)
                )
            }
        }
        setMeasuredDimension(width, ch)
    }
}

/** Akar input view. Saat mode mengambang tingginya setinggi layar supaya kartu bisa digeser. */
class InputRoot(ctx: Context) : FrameLayout(ctx) {
    var fullHeight = 0
    override fun onMeasure(w: Int, h: Int) {
        if (fullHeight > 0) super.onMeasure(w, MeasureSpec.makeMeasureSpec(fullHeight, MeasureSpec.EXACTLY))
        else super.onMeasure(w, h)
    }
}

class KeyboardUi(private val s: KeyboardService) {
    private val d = s.resources.displayMetrics.density
    private fun dp(v: Float) = (v * d).toInt()

    val root = InputRoot(s)
    private val card = KeyboardCard(s)
    private val bgImage = BgImageView(s)
    private val bgVideo = VideoBgView(s)
    private val dim = View(s)
    private val content = LinearLayout(s).apply { orientation = LinearLayout.VERTICAL }
    private val handle = LinearLayout(s)
    private val bar = LinearLayout(s)
    private val body = FrameLayout(s)
    private val sug = Array(3) { TextView(s) }
    private var lastSug: List<String> = emptyList()
    private var pal = s.prefs.palette()
    private var rowH = 0
    private var emojiCat = 0
    private val letterKeys = mutableListOf<KeyView>()
    private var shiftKey: KeyView? = null
    private val handler = Handler(Looper.getMainLooper())
    private var welcome = false
    private var floating = false
    private var hasBg = false
    private var previewPop: PopupWindow? = null

    init {
        card.addView(bgImage, FrameLayout.LayoutParams(-1, -1))
        card.addView(bgVideo, FrameLayout.LayoutParams(-1, -1))
        card.addView(dim, FrameLayout.LayoutParams(-1, -1))
        content.addView(handle)
        content.addView(bar)
        content.addView(body)
        card.addView(content, FrameLayout.LayoutParams(-1, -2))
        root.addView(card, FrameLayout.LayoutParams(-1, -2))
        rebuild()
    }

    fun rebuild() {
        val p = s.prefs
        pal = p.palette()
        rowH = dp(52f * p.heightPercent / 100f)
        floating = p.floating
        hidePreview()
        applyShell(p)
        content.setPadding(0, 0, 0, dp(p.bottomPad.toFloat()))
        letterKeys.clear()
        shiftKey = null
        buildHandle()
        buildBar()
        swapBody(
            when (s.panel) {
                Panel.EMOJI -> buildEmoji()
                Panel.CLIP -> buildClip()
                Panel.MENU -> buildMenu()
                Panel.EDIT -> buildEdit()
                Panel.SNIPPETS -> buildSnippets()
                else -> buildKeys()
            }
        )
        refreshShift()
    }

    // ---------- Cangkang: posisi, latar, mode mengambang / satu tangan ----------
    private fun applyShell(p: Prefs) {
        val sw = s.resources.displayMetrics.widthPixels
        val sh = s.resources.displayMetrics.heightPixels
        val lp = card.layoutParams as FrameLayout.LayoutParams
        val radius = if (floating) dp(16f).toFloat() else 0f
        val bgd = GradientDrawable()
        bgd.setColor(pal.bg)
        bgd.cornerRadius = radius
        card.background = bgd
        card.outlineProvider = ViewOutlineProvider.BACKGROUND
        card.clipToOutline = radius > 0f
        card.elevation = if (floating) dp(8f).toFloat() else 0f

        if (floating) {
            root.fullHeight = sh
            val w = (sw * p.floatW / 100f).toInt().coerceAtLeast(dp(260f)).coerceAtMost(sw)
            val est = rowH * (if (p.numberRow) 5 else 4) + dp(72f)
            val x = if (p.floatX < 0) (sw - w) / 2 else p.floatX
            val y = if (p.floatY < 0) sh - est - dp(110f) else p.floatY
            lp.width = w
            lp.height = FrameLayout.LayoutParams.WRAP_CONTENT
            lp.gravity = Gravity.TOP or Gravity.START
            lp.leftMargin = x.coerceIn(0, max(0, sw - w))
            lp.topMargin = y.coerceIn(0, max(0, sh - est))
        } else {
            root.fullHeight = 0
            lp.width = if (p.oneHand == "off") FrameLayout.LayoutParams.MATCH_PARENT else (sw * 0.8f).toInt()
            lp.height = FrameLayout.LayoutParams.WRAP_CONTENT
            lp.gravity = Gravity.BOTTOM or when (p.oneHand) {
                "left" -> Gravity.START
                "right" -> Gravity.END
                else -> Gravity.CENTER_HORIZONTAL
            }
            lp.leftMargin = 0
            lp.topMargin = 0
        }
        card.layoutParams = lp

        val kind = p.bgKind()
        hasBg = kind != "none"
        bgImage.visibility = if (kind == "image") View.VISIBLE else View.GONE
        bgVideo.visibility = if (kind == "video") View.VISIBLE else View.GONE
        dim.visibility = if (hasBg) View.VISIBLE else View.GONE
        dim.setBackgroundColor(Color.argb(p.bgDim * 255 / 100, 0, 0, 0))
        bgImage.load(if (kind == "image") p.bgImageFile() else null)
        bgVideo.setSource(if (kind == "video") p.bgVideoFile().absolutePath else null)
    }

    fun bgStart() { if (s.prefs.bgKind() == "video") bgVideo.start() }
    fun bgStop() { bgVideo.stop() }

    /** Keyboard naik perlahan saat ditampilkan (tidak dipakai saat mengambang agar sentuhan tetap akurat). */
    fun playEntrance() {
        if (floating) return
        card.translationY = dp(26f).toFloat()
        card.alpha = 0.3f
        card.animate().translationY(0f).alpha(1f).setDuration(240L)
            .setInterpolator(DecelerateInterpolator()).start()
    }

    /** Ganti isi papan (huruf, simbol, panel) dengan transisi naik dan memudar. */
    private fun swapBody(v: View) {
        body.removeAllViews()
        body.addView(v)
        v.alpha = 0f
        v.translationY = dp(12f).toFloat()
        v.animate().alpha(1f).translationY(0f).setDuration(190L)
            .setInterpolator(DecelerateInterpolator()).start()
    }

    fun rootHeight() = root.height

    /** Area yang bisa disentuh saat mengambang (koordinat jendela); null jika tidak mengambang. */
    fun floatRegion(): Rect? {
        if (!floating) return null
        val loc = IntArray(2)
        card.getLocationInWindow(loc)
        return Rect(loc[0], loc[1], loc[0] + card.width, loc[1] + card.height)
    }

    private fun buildHandle() {
        handle.removeAllViews()
        if (!floating) {
            handle.visibility = View.GONE
            return
        }
        handle.visibility = View.VISIBLE
        handle.orientation = LinearLayout.HORIZONTAL
        handle.gravity = Gravity.CENTER_VERTICAL
        handle.layoutParams = LinearLayout.LayoutParams(-1, dp(30f))
        val drag = TextView(s)
        drag.text = "≡  geser di sini"
        drag.textSize = 12f
        drag.gravity = Gravity.CENTER
        drag.setTextColor(ColorUtils.setAlphaComponent(pal.text, 170))
        drag.layoutParams = LinearLayout.LayoutParams(0, -1, 1f)
        var offX = 0f
        var offY = 0f
        drag.setOnTouchListener { _, e ->
            val lp = card.layoutParams as FrameLayout.LayoutParams
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    offX = e.rawX - lp.leftMargin
                    offY = e.rawY - lp.topMargin
                }
                MotionEvent.ACTION_MOVE -> {
                    val maxX = max(0, root.width - card.width)
                    val maxY = max(0, root.height - card.height)
                    lp.leftMargin = (e.rawX - offX).toInt().coerceIn(0, maxX)
                    lp.topMargin = (e.rawY - offY).toInt().coerceIn(0, maxY)
                    card.layoutParams = lp
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    s.prefs.floatX = lp.leftMargin
                    s.prefs.floatY = lp.topMargin
                }
            }
            true
        }
        handle.addView(drag)
        fun tool(label: String, w: Float, action: () -> Unit) {
            val t = TextView(s)
            t.text = label
            t.textSize = 14f
            t.setTextColor(pal.text)
            t.gravity = Gravity.CENTER
            t.layoutParams = LinearLayout.LayoutParams(dp(w), -1)
            t.bounce()
            t.setOnClickListener { s.feedback(); action() }
            handle.addView(t)
        }
        fun resize(delta: Int) {
            val nw = (s.prefs.floatW + delta).coerceIn(50, 100)
            s.prefs.sp.edit().putInt("float_w", nw).apply()
            rebuild()
        }
        tool("−", 36f) { resize(-5) }
        tool("+", 36f) { resize(5) }
        tool("Dok", 48f) { s.setFloating(false) }
    }

    // ---------- Saran kata & sambutan ----------
    fun setSuggestions(l: List<String>) {
        if (l.isNotEmpty()) welcome = false
        lastSug = l
        if (welcome) return
        sug[0].visibility = View.VISIBLE
        sug[2].visibility = View.VISIBLE
        sug.forEachIndexed { i, tv ->
            val t = l.getOrNull(i) ?: ""
            if (tv.text.toString() != t) {
                tv.text = t
                tv.alpha = 0.35f
                tv.animate().alpha(1f).setDuration(160L).start()
            }
        }
    }

    fun showWelcome() {
        welcome = true
        applyWelcome()
        handler.postDelayed({
            welcome = false
            setSuggestions(lastSug)
        }, 4500)
    }

    private fun applyWelcome() {
        if (!welcome) return
        sug[0].visibility = View.GONE
        sug[2].visibility = View.GONE
        sug[1].text = "Selamat Datang Di My Keyboard"
    }

    fun refreshShift() {
        val up = s.shift != 0
        letterKeys.forEach {
            val c = it.tag as String
            it.label = if (up) c.uppercase() else c
            it.invalidate()
        }
        shiftKey?.let {
            it.label = ""
            it.icon = when (s.shift) { 0 -> Ic.SHIFT; 1 -> Ic.SHIFT_ON; else -> Ic.CAPS }
            it.fill = if (s.shift == 2) pal.accent else fk(pal.func)
            it.textColor = if (s.shift == 2) onAccent() else pal.text
            it.invalidate()
        }
    }

    private fun onAccent() = if (ColorUtils.calculateLuminance(pal.accent) > 0.5) Color.BLACK else Color.WHITE

    /** Beri transparansi pada warna tombol bila ada latar foto/video. */
    private fun fk(c: Int) = if (hasBg) ColorUtils.setAlphaComponent(c, s.prefs.keyAlpha * 255 / 100) else c

    // ---------- Bar atas ----------
    private fun buildBar() {
        bar.removeAllViews()
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.layoutParams = LinearLayout.LayoutParams(-1, dp(40f))
        sug.forEachIndexed { i, tv ->
            tv.setTextColor(pal.text)
            tv.textSize = 16f
            tv.gravity = Gravity.CENTER
            tv.maxLines = 1
            tv.ellipsize = TextUtils.TruncateAt.END
            tv.text = lastSug.getOrNull(i) ?: ""
            tv.visibility = View.VISIBLE
            tv.layoutParams = LinearLayout.LayoutParams(0, -1, 1f)
            tv.setOnClickListener {
                val t = tv.text.toString()
                if (t.isNotEmpty() && !welcome) { s.feedback(); s.pickSuggestion(t) }
            }
            bar.addView(tv)
        }
        applyWelcome()
        fun tool(ic: Ic, action: () -> Unit) {
            val t = IconView(s, ic, pal.text)
            t.layoutParams = LinearLayout.LayoutParams(dp(42f), -1)
            t.bounce()
            t.setOnClickListener { s.feedback(); action() }
            bar.addView(t)
        }
        tool(Ic.EMOJI) { s.openPanel(if (s.panel == Panel.EMOJI) Panel.KEYS else Panel.EMOJI) }
        tool(Ic.CLIP) { s.openPanel(if (s.panel == Panel.CLIP) Panel.KEYS else Panel.CLIP) }
        tool(Ic.MIC) { s.startVoice() }
        tool(Ic.SLIDERS) { s.openPanel(if (s.panel == Panel.MENU) Panel.KEYS else Panel.MENU) }
    }

    // ---------- Pembuat tombol ----------
    private fun row() = LinearLayout(s).apply {
        orientation = LinearLayout.HORIZONTAL
        layoutParams = LinearLayout.LayoutParams(-1, rowH)
    }

    private fun spacer(w: Float) = View(s).apply { layoutParams = LinearLayout.LayoutParams(0, rowH, w) }

    private fun iconKey(ic: Ic, w: Float, func: Boolean = true): KeyView = key("", w, func).also { it.icon = ic }

    private fun key(label: String, w: Float, func: Boolean = false, hint: String? = null): KeyView {
        val p = s.prefs
        val k = KeyView(s)
        k.layoutParams = LinearLayout.LayoutParams(0, rowH, w)
        k.label = label
        k.hint = if (p.hints) hint else null
        k.fill = fk(if (func) pal.func else pal.key)
        k.fillPressed = pal.pressed
        k.textColor = pal.text
        k.hintColor = ColorUtils.setAlphaComponent(pal.text, 140)
        k.radiusPx = dp(p.radius.toFloat()).toFloat()
        k.gapPx = dp(p.gap / 2f).toFloat()
        k.textPx = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, p.textSize.toFloat(), s.resources.displayMetrics)
        k.bold = p.bold
        if (label.codePointCount(0, label.length) > 1) k.textScale = 0.62f
        return k
    }

    private fun attach(
        v: KeyView,
        repeat: Boolean = false,
        onLong: (() -> Unit)? = null,
        onDrag: ((Int) -> Unit)? = null,
        onPress: ((Boolean) -> Unit)? = null,
        onTap: () -> Unit
    ) {
        var done = false
        var dragged = false
        var lastX = 0f
        val step = dp(14f).toFloat()
        val longRun = Runnable {
            done = true
            s.feedback()
            onLong?.invoke()
            v.isPressed = false
            v.invalidate()
            onPress?.invoke(false)
        }
        val repRun = object : Runnable {
            override fun run() { onTap(); handler.postDelayed(this, 45) }
        }
        fun stop() { handler.removeCallbacks(longRun); handler.removeCallbacks(repRun) }
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    done = false
                    dragged = false
                    lastX = e.x
                    v.isPressed = true
                    v.invalidate()
                    s.feedback()
                    onPress?.invoke(true)
                    if (repeat) { onTap(); handler.postDelayed(repRun, 380) }
                    else if (onLong != null) handler.postDelayed(longRun, s.prefs.longPressMs.toLong())
                }
                MotionEvent.ACTION_MOVE -> {
                    if (onDrag != null) {
                        val dx = e.x - lastX
                        if (abs(dx) >= step) {
                            val n = (dx / step).toInt()
                            lastX += n * step
                            dragged = true
                            onDrag(n)
                        }
                    } else if (!done && (e.x < 0 || e.y < 0 || e.x > v.width || e.y > v.height)) {
                        done = true
                        stop()
                        v.isPressed = false
                        v.invalidate()
                        onPress?.invoke(false)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    stop()
                    if (!repeat && !done && !dragged) onTap()
                    v.isPressed = false
                    v.invalidate()
                    onPress?.invoke(false)
                }
                MotionEvent.ACTION_CANCEL -> {
                    stop()
                    v.isPressed = false
                    v.invalidate()
                    onPress?.invoke(false)
                }
            }
            true
        }
    }

    // ---------- Pratinjau tombol ----------
    private fun showPreview(v: View, label: String) {
        hidePreview()
        try {
            val t = TextView(s)
            t.text = label
            t.gravity = Gravity.CENTER
            t.textSize = 28f
            t.setTextColor(pal.text)
            val g = GradientDrawable()
            g.setColor(ColorUtils.setAlphaComponent(pal.key, 255))
            g.cornerRadius = dp(10f).toFloat()
            g.setStroke(dp(1f), pal.accent)
            t.background = g
            val w = max(v.width, dp(48f))
            val h = dp(60f)
            val pop = PopupWindow(t, w, h, false)
            pop.isTouchable = false
            pop.animationStyle = R.style.KeyPreviewAnim
            pop.showAsDropDown(v, (v.width - w) / 2, -(v.height + h))
            previewPop = pop
        } catch (e: Exception) { }
    }

    private fun hidePreview() {
        try { previewPop?.dismiss() } catch (e: Exception) { }
        previewPop = null
    }

    private fun charKey(c: String, w: Float, hint: String?): KeyView {
        val k = key(c, w, false, hint)
        if (c[0].isLetter()) { k.tag = c; letterKeys.add(k) }
        attach(
            k,
            onLong = hint?.let { h -> { s.typeLiteral(h) } },
            onPress = { down -> if (down && s.prefs.keyPreview) showPreview(k, k.label) else hidePreview() }
        ) { s.typeChar(c) }
        return k
    }

    private fun delKey(w: Float): KeyView {
        val k = iconKey(Ic.BACKSPACE, w)
        attach(k, repeat = true) { s.backspace() }
        return k
    }

    private fun spaceKey(w: Float): KeyView {
        val k = key(if (s.mode == Mode.NUM) "space" else s.prefs.layout.uppercase(), w)
        k.textScale = 0.5f
        val swipe: (Int) -> Unit = { n -> s.moveCursorBy(n) }
        attach(k, onDrag = if (s.prefs.spaceSwipe) swipe else null) { s.space() }
        return k
    }

    private fun enterKey(w: Float): KeyView {
        val k = key(s.enterLabel(), w, true)
        k.fill = pal.accent
        k.textColor = onAccent()
        attach(k) { s.enter() }
        return k
    }

    // ---------- Papan huruf / simbol / angka ----------
    private fun buildKeys(): View {
        val col = LinearLayout(s)
        col.orientation = LinearLayout.VERTICAL
        col.layoutParams = FrameLayout.LayoutParams(-1, -2)
        when (s.mode) {
            Mode.NUM -> numRows(col)
            Mode.LETTERS -> { letterRows(col); col.addView(bottomRow()) }
            else -> { symbolRows(col); col.addView(bottomRow()) }
        }
        return col
    }

    private fun letterRows(col: LinearLayout) {
        val p = s.prefs
        if (p.numberRow) {
            val r = row()
            Layouts.digits.forEach { r.addView(charKey(it, 1f, null)) }
            col.addView(r)
        }
        Layouts.letters(p.layout).forEachIndexed { i, chars ->
            val r = row()
            val n = chars.size
            val side = max(1f, (10 - n) / 2f)
            if (i == 1 && n < 10) r.addView(spacer((10 - n) / 2f))
            if (i == 2) {
                val sk = iconKey(Ic.SHIFT, side)
                shiftKey = sk
                attach(sk) { s.toggleShift() }
                r.addView(sk)
            }
            chars.forEachIndexed { j, c ->
                val hint = when (i) {
                    0 -> if (!p.numberRow) Layouts.digits.getOrNull(j) else null
                    1 -> Layouts.hint2.getOrNull(j)
                    else -> Layouts.hint3.getOrNull(j)
                }
                r.addView(charKey(c, 1f, hint))
            }
            if (i == 1 && n < 10) r.addView(spacer((10 - n) / 2f))
            if (i == 2) r.addView(delKey(side))
            col.addView(r)
        }
    }

    private fun symbolRows(col: LinearLayout) {
        val page = if (s.mode == Mode.SYM1) 1 else 2
        val rows = Layouts.symbols(page, s.prefs.numberRow)
        rows.forEachIndexed { i, chars ->
            val r = row()
            val last = i == rows.size - 1
            if (last) {
                val t = key(if (page == 1) "=\\<" else "?123", 1.5f, true)
                attach(t) { s.changeMode(if (page == 1) Mode.SYM2 else Mode.SYM1) }
                r.addView(t)
            }
            chars.forEach { r.addView(charKey(it, 1f, null)) }
            if (last) r.addView(delKey(1.5f))
            col.addView(r)
        }
    }

    private fun numRows(col: LinearLayout) {
        val sym4 = if (s.isPhone) "+" else "-"
        val spec = listOf(
            listOf("1", "2", "3", "DEL"), listOf("4", "5", "6", sym4),
            listOf("7", "8", "9", "."), listOf(",", "0", "SPACE", "ENTER")
        )
        spec.forEach { names ->
            val r = row()
            names.forEach { n ->
                r.addView(
                    when (n) {
                        "DEL" -> delKey(1f)
                        "SPACE" -> spaceKey(1f)
                        "ENTER" -> enterKey(1f)
                        else -> charKey(n, 1f, null)
                    }
                )
            }
            col.addView(r)
        }
    }

    private fun bottomRow(): LinearLayout {
        val r = row()
        val t = key(if (s.mode == Mode.LETTERS) "?123" else "ABC", 1.5f, true)
        attach(t) { s.toggleSymbols() }
        r.addView(t)
        val g = iconKey(Ic.GLOBE, 1f)
        attach(g) { s.pickIme() }
        r.addView(g)
        val comma = key(",", 1f)
        attach(comma, onLong = { s.openPanel(Panel.EMOJI) }) { s.typeLiteral(",") }
        r.addView(comma)
        r.addView(spaceKey(4f))
        val dot = key(".", 1f)
        attach(dot) { s.typeLiteral(".") }
        r.addView(dot)
        r.addView(enterKey(1.5f))
        return r
    }

    // ---------- Panel umum ----------
    private fun panelHeight() = rowH * (if (s.prefs.numberRow) 5 else 4)

    private fun panelBox(content: View, bottom: LinearLayout): View {
        val box = LinearLayout(s)
        box.orientation = LinearLayout.VERTICAL
        box.layoutParams = FrameLayout.LayoutParams(-1, panelHeight())
        content.layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
        box.addView(content)
        box.addView(bottom)
        return box
    }

    private fun backKey(): KeyView {
        val k = key("ABC", 1.5f, true)
        attach(k) { s.closePanel() }
        return k
    }

    // ---------- Panel emoji ----------
    private fun buildEmoji(): View {
        val scroll = ScrollView(s)
        val list = LinearLayout(s)
        list.orientation = LinearLayout.VERTICAL
        val perRow = 8
        EmojiData.cats[emojiCat].second.chunked(perRow).forEach { chunk ->
            val r = LinearLayout(s)
            r.orientation = LinearLayout.HORIZONTAL
            r.layoutParams = LinearLayout.LayoutParams(-1, (rowH * 0.9f).toInt())
            for (i in 0 until perRow) {
                val tv = TextView(s)
                tv.gravity = Gravity.CENTER
                tv.textSize = 24f
                tv.layoutParams = LinearLayout.LayoutParams(0, -1, 1f)
                chunk.getOrNull(i)?.let { e ->
                    tv.text = e
                    tv.bounce()
                    tv.setOnClickListener { s.feedback(); s.commitRaw(e) }
                }
                r.addView(tv)
            }
            list.addView(r)
        }
        scroll.addView(list)
        val bottom = row()
        bottom.addView(backKey())
        EmojiData.cats.forEachIndexed { i, c ->
            val k = key(c.first, 1f, i != emojiCat)
            k.textScale = 0.55f
            attach(k) { emojiCat = i; rebuild() }
            bottom.addView(k)
        }
        bottom.addView(delKey(1.5f))
        return panelBox(scroll, bottom)
    }

    // ---------- Panel clipboard ----------
    private fun buildClip(): View {
        val scroll = ScrollView(s)
        val list = LinearLayout(s)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(dp(8f), dp(4f), dp(8f), dp(4f))
        val clips = s.prefs.clips()
        if (clips.isEmpty()) {
            val tv = TextView(s)
            tv.text = "Belum ada riwayat clipboard.\nSalin teks, nanti muncul di sini."
            tv.setTextColor(pal.text)
            tv.gravity = Gravity.CENTER
            tv.setPadding(0, dp(24f), 0, 0)
            list.addView(tv)
        }
        clips.forEach { c ->
            val tv = TextView(s)
            tv.text = c
            tv.maxLines = 2
            tv.ellipsize = TextUtils.TruncateAt.END
            tv.setTextColor(pal.text)
            tv.textSize = 15f
            tv.setPadding(dp(12f), dp(10f), dp(12f), dp(10f))
            tv.background = GradientDrawable().apply {
                setColor(fk(pal.key))
                cornerRadius = dp(s.prefs.radius.toFloat()).toFloat()
            }
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.setMargins(0, dp(3f), 0, dp(3f))
            tv.layoutParams = lp
            tv.bounce()
            tv.setOnClickListener { s.feedback(); s.commitRaw(c) }
            list.addView(tv)
        }
        scroll.addView(list)
        val bottom = row()
        bottom.addView(backKey())
        val clear = key("Hapus semua", 3f, true)
        clear.textScale = 0.6f
        attach(clear) { s.prefs.clearClips(); rebuild() }
        bottom.addView(clear)
        bottom.addView(spacer(3.5f))
        bottom.addView(delKey(1.5f))
        return panelBox(scroll, bottom)
    }

    // ---------- Panel teks cepat ----------
    private fun buildSnippets(): View {
        val scroll = ScrollView(s)
        val list = LinearLayout(s)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(dp(8f), dp(4f), dp(8f), dp(4f))
        val items = s.prefs.snippets()
        if (items.isEmpty()) {
            val empty = TextView(s)
            empty.text = "Belum ada teks cepat.\nKetuk Kelola untuk menambah. Ketuk isinya di sini untuk menyisipkan."
            empty.setTextColor(pal.text)
            empty.gravity = Gravity.CENTER
            empty.setPadding(0, dp(24f), 0, 0)
            list.addView(empty)
        }
        items.forEach { sn ->
            val box = LinearLayout(s)
            box.orientation = LinearLayout.VERTICAL
            box.setPadding(dp(12f), dp(8f), dp(12f), dp(8f))
            box.background = GradientDrawable().apply {
                setColor(fk(pal.key))
                cornerRadius = dp(s.prefs.radius.toFloat()).toFloat()
            }
            val title = TextView(s)
            title.text = sn.title
            title.setTextColor(pal.accent)
            title.textSize = 14f
            title.typeface = Typeface.DEFAULT_BOLD
            title.maxLines = 1
            title.ellipsize = TextUtils.TruncateAt.END
            val desc = TextView(s)
            desc.text = sn.text
            desc.setTextColor(pal.text)
            desc.textSize = 13f
            desc.maxLines = 2
            desc.ellipsize = TextUtils.TruncateAt.END
            box.addView(title)
            box.addView(desc)
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.setMargins(0, dp(3f), 0, dp(3f))
            box.layoutParams = lp
            box.bounce()
            box.setOnClickListener { s.feedback(); s.commitRaw(sn.text) }
            list.addView(box)
        }
        scroll.addView(list)
        val bottom = row()
        bottom.addView(backKey())
        val manage = key("Kelola", 3f, true)
        manage.textScale = 0.7f
        attach(manage) { s.openSnippetManager() }
        bottom.addView(manage)
        bottom.addView(spacer(3.5f))
        bottom.addView(delKey(1.5f))
        return panelBox(scroll, bottom)
    }

    // ---------- Panel edit teks ----------
    private fun buildEdit(): View {
        val grid = LinearLayout(s)
        grid.orientation = LinearLayout.VERTICAL

        fun fill(k: KeyView): KeyView {
            k.layoutParams = LinearLayout.LayoutParams(0, -1, 1f)
            return k
        }
        fun act(label: String, on: Boolean = false, repeat: Boolean = false, f: () -> Unit): KeyView {
            val k = key(label, 1f, true)
            if (on) { k.fill = pal.accent; k.textColor = onAccent() }
            attach(k, repeat = repeat) { f() }
            return fill(k)
        }
        fun rowOf(vararg ks: KeyView): LinearLayout {
            val r = LinearLayout(s)
            r.orientation = LinearLayout.HORIZONTAL
            r.layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
            ks.forEach { r.addView(it) }
            return r
        }

        grid.addView(rowOf(
            act("Home") { s.cursorKey(KeyEvent.KEYCODE_MOVE_HOME) },
            act("↑", repeat = true) { s.cursorKey(KeyEvent.KEYCODE_DPAD_UP) },
            act("End") { s.cursorKey(KeyEvent.KEYCODE_MOVE_END) },
            fill(delKey(1f))
        ))
        grid.addView(rowOf(
            act("←", repeat = true) { s.cursorKey(KeyEvent.KEYCODE_DPAD_LEFT) },
            act("Pilih", on = s.selectMode) { s.selectMode = !s.selectMode; rebuild() },
            act("→", repeat = true) { s.cursorKey(KeyEvent.KEYCODE_DPAD_RIGHT) },
            act("Semua") { s.menuAction(android.R.id.selectAll) }
        ))
        grid.addView(rowOf(
            act("Salin") { s.menuAction(android.R.id.copy) },
            act("↓", repeat = true) { s.cursorKey(KeyEvent.KEYCODE_DPAD_DOWN) },
            act("Potong") { s.menuAction(android.R.id.cut) },
            act("Tempel") { s.menuAction(android.R.id.paste) }
        ))
        val bottom = row()
        bottom.addView(backKey())
        bottom.addView(spacer(8.5f))
        return panelBox(grid, bottom)
    }

    // ---------- Menu cepat ----------
    private fun sectionLabel(t: String): TextView {
        val v = TextView(s)
        v.text = t.uppercase()
        v.textSize = 11f
        v.letterSpacing = 0.08f
        v.setTextColor(ColorUtils.setAlphaComponent(pal.text, 150))
        v.setPadding(dp(4f), dp(10f), 0, dp(4f))
        return v
    }

    private fun pill(label: String, on: Boolean, action: () -> Unit): TextView {
        val t = TextView(s)
        t.text = label
        t.textSize = 13f
        t.gravity = Gravity.CENTER
        t.maxLines = 1
        t.ellipsize = TextUtils.TruncateAt.END
        t.setTextColor(if (on) onAccent() else pal.text)
        val g = GradientDrawable()
        g.setColor(if (on) pal.accent else fk(pal.func))
        g.cornerRadius = dp(s.prefs.radius.toFloat()).toFloat()
        t.background = g
        val lp = LinearLayout.LayoutParams(0, dp(42f), 1f)
        lp.setMargins(dp(3f), dp(3f), dp(3f), dp(3f))
        t.layoutParams = lp
        t.bounce()
        t.setOnClickListener { s.feedback(); action() }
        return t
    }

    private fun pillRow(vararg v: View): LinearLayout {
        val r = LinearLayout(s)
        r.orientation = LinearLayout.HORIZONTAL
        v.forEach { r.addView(it) }
        return r
    }

    private fun swatch(id: String, p: Palette, selected: Boolean): View {
        val v = View(s)
        val sz = dp(40f)
        val lp = LinearLayout.LayoutParams(sz, sz)
        lp.setMargins(dp(4f), dp(4f), dp(4f), dp(4f))
        v.layoutParams = lp
        val g = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(p.bg, p.key))
        g.shape = GradientDrawable.OVAL
        g.setStroke(dp(if (selected) 3f else 1f), if (selected) pal.accent else ColorUtils.setAlphaComponent(pal.text, 90))
        v.background = g
        v.bounce()
        v.setOnClickListener {
            s.feedback()
            s.prefs.sp.edit().putString("theme", id).apply()
            rebuild()
        }
        return v
    }

    private fun toggle(key: String, cur: Boolean) {
        s.prefs.sp.edit().putBoolean(key, !cur).apply()
        rebuild()
    }

    private fun buildMenu(): View {
        val p = s.prefs
        val scroll = ScrollView(s)
        val list = LinearLayout(s)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(dp(8f), dp(4f), dp(8f), dp(4f))

        list.addView(sectionLabel("Tema"))
        val hs = HorizontalScrollView(s)
        hs.isHorizontalScrollBarEnabled = false
        val sw = LinearLayout(s)
        sw.orientation = LinearLayout.HORIZONTAL
        val cur = p.theme
        Themes.list.forEach { sw.addView(swatch(it.id, it.pal, cur == it.id)) }
        sw.addView(swatch("custom", p.custom(), cur == "custom"))
        hs.addView(sw)
        list.addView(hs)

        list.addView(sectionLabel("Mode layar"))
        list.addView(pillRow(
            pill("Mengambang", p.floating) { s.setFloating(!p.floating) },
            pill("Tangan kiri", p.oneHand == "left") { s.setOneHand(if (p.oneHand == "left") "off" else "left") },
            pill("Tangan kanan", p.oneHand == "right") { s.setOneHand(if (p.oneHand == "right") "off" else "right") }
        ))
        list.addView(pillRow(
            pill("Baris angka", p.numberRow) { toggle("number_row", p.numberRow) },
            pill("Petunjuk", p.hints) { toggle("hints", p.hints) },
            pill("Getar", p.vibrate) { toggle("vibrate", p.vibrate) }
        ))

        list.addView(sectionLabel("Alat"))
        list.addView(pillRow(
            pill("Teks cepat", false) { s.openPanel(Panel.SNIPPETS) },
            pill("Edit teks", false) { s.openPanel(Panel.EDIT) },
            pill("Suara", false) { s.startVoice() }
        ))
        list.addView(pillRow(
            pill("Pengaturan", false) {
                s.startActivity(Intent(s, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            },
            pill("Ganti keyboard", false) { s.pickIme() },
            pill("Tutup", false) { s.requestHideSelf(0) }
        ))

        val foot = TextView(s)
        foot.text = "My Keyboard  \u2022  By Fidzz"
        foot.textSize = 11f
        foot.gravity = Gravity.CENTER
        foot.setTextColor(ColorUtils.setAlphaComponent(pal.text, 120))
        foot.setPadding(0, dp(14f), 0, dp(6f))
        list.addView(foot)

        scroll.addView(list)
        val bottom = row()
        bottom.addView(backKey())
        bottom.addView(spacer(8.5f))
        return panelBox(scroll, bottom)
    }
}
