package com.example.mykeyboard

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import androidx.core.graphics.ColorUtils
import androidx.preference.PreferenceManager
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Teks cepat: judul singkat dan isi yang disisipkan ke teks. */
data class Snippet(val title: String, val text: String)

data class Palette(val bg: Int, val key: Int, val func: Int, val text: Int, val accent: Int, val pressed: Int)

data class ThemeDef(val id: String, val name: String, val pal: Palette)

object Themes {
    fun make(bg: Int, key: Int, func: Int, text: Int, accent: Int) =
        Palette(bg, key, func, text, accent, ColorUtils.blendARGB(key, accent, 0.35f))

    private fun p(bg: String, key: String, func: String, text: String, accent: String) =
        make(Color.parseColor(bg), Color.parseColor(key), Color.parseColor(func), Color.parseColor(text), Color.parseColor(accent))

    val list: List<ThemeDef> = listOf(
        ThemeDef("dark", "Gelap", p("#202124", "#3C4043", "#2D2F31", "#FFFFFF", "#8AB4F8")),
        ThemeDef("light", "Terang", p("#D1D5DB", "#FFFFFF", "#B6BCC6", "#111111", "#1A73E8")),
        ThemeDef("amoled", "AMOLED", p("#000000", "#121212", "#1E1E1E", "#FFFFFF", "#00E5FF")),
        ThemeDef("ocean", "Samudra", p("#0B2545", "#13315C", "#1C4A82", "#EEF4ED", "#8DA9C4")),
        ThemeDef("sakura", "Sakura", p("#FADADD", "#FFFFFF", "#F4B6C2", "#5B2333", "#E75480")),
        ThemeDef("hacker", "Hacker", p("#000000", "#0A140A", "#102010", "#33FF33", "#33FF33")),
        ThemeDef("forest", "Hutan", p("#12261C", "#1E3D2E", "#2A5440", "#E6F4EA", "#7BD389")),
        ThemeDef("sunset", "Senja", p("#2B1020", "#4A1D3A", "#6A2A4A", "#FFE9D6", "#FF8A5B")),
        ThemeDef("lavender", "Lavender", p("#E9E3F7", "#FFFFFF", "#CFC3EA", "#2D2150", "#7C4DFF")),
        ThemeDef("mocha", "Mocha", p("#2A1E17", "#43302A", "#5A4036", "#F5E6D8", "#D9A066")),
        ThemeDef("neon", "Neon", p("#0A0014", "#1A0B2E", "#2B1250", "#F5F5FF", "#FF2ED1")),
        ThemeDef("mint", "Mint", p("#DDF3EA", "#FFFFFF", "#B7E3D0", "#123B2E", "#12B886")),
        ThemeDef("gold", "Emas", p("#14110A", "#2A2415", "#3D3420", "#FFF3C4", "#FFC107"))
    )

    fun byId(id: String): ThemeDef? = list.firstOrNull { it.id == id }
}

class Prefs(private val ctx: Context) {
    val sp: SharedPreferences = PreferenceManager.getDefaultSharedPreferences(ctx)

    val layout get() = sp.getString("layout", "qwerty") ?: "qwerty"
    val theme get() = sp.getString("theme", "dark") ?: "dark"
    val numberRow get() = sp.getBoolean("number_row", true)
    val hints get() = sp.getBoolean("hints", true)
    val bold get() = sp.getBoolean("bold", false)
    val heightPercent get() = sp.getInt("height", 100)
    val textSize get() = sp.getInt("text_size", 20)
    val radius get() = sp.getInt("radius", 10)
    val gap get() = sp.getInt("gap", 3)
    val bottomPad get() = sp.getInt("bottom_pad", 0)
    val autoCap get() = sp.getBoolean("auto_cap", true)
    val suggestions get() = sp.getBoolean("suggestions", true)
    val doubleSpace get() = sp.getBoolean("double_space", true)
    val clipEnabled get() = sp.getBoolean("clip_enabled", true)
    val vibrate get() = sp.getBoolean("vibrate", true)
    val vibrateMs get() = sp.getInt("vibrate_ms", 15)
    val sound get() = sp.getBoolean("sound", false)

    // Baru
    val keyPreview get() = sp.getBoolean("key_preview", true)
    val spaceSwipe get() = sp.getBoolean("space_swipe", true)
    val longPressMs get() = sp.getInt("long_press", 330)
    val floating get() = sp.getBoolean("floating", false)
    val floatW get() = sp.getInt("float_w", 85)
    val oneHand get() = sp.getString("one_hand", "off") ?: "off"
    val bgType get() = sp.getString("bg_type", "none") ?: "none"
    val bgDim get() = sp.getInt("bg_dim", 35)
    val keyAlpha get() = sp.getInt("key_alpha", 75)

    var floatX: Int
        get() = sp.getInt("float_x", -1)
        set(v) { sp.edit().putInt("float_x", v).apply() }

    var floatY: Int
        get() = sp.getInt("float_y", -1)
        set(v) { sp.edit().putInt("float_y", v).apply() }

    fun bgImageFile() = File(ctx.filesDir, "bg_image.jpg")
    fun bgVideoFile() = File(ctx.filesDir, "bg_video.mp4")

    /** "image", "video", atau "none" (file harus benar-benar ada). */
    fun bgKind(): String = when {
        bgType == "image" && bgImageFile().exists() -> "image"
        bgType == "video" && bgVideoFile().exists() -> "video"
        else -> "none"
    }

    fun color(key: String, def: String): Int =
        try { Color.parseColor((sp.getString(key, def) ?: def).trim()) } catch (e: Exception) { Color.parseColor(def) }

    fun custom(): Palette = Themes.make(
        color("color_bg", "#202124"), color("color_key", "#3C4043"), color("color_func", "#2D2F31"),
        color("color_text", "#FFFFFF"), color("color_accent", "#8AB4F8")
    )

    fun palette(): Palette =
        if (theme == "custom") custom() else (Themes.byId(theme) ?: Themes.list[0]).pal

    // Clipboard history
    fun clips(): MutableList<String> {
        val out = mutableListOf<String>()
        try {
            val a = JSONArray(sp.getString("clips", "[]"))
            for (i in 0 until a.length()) out.add(a.getString(i))
        } catch (e: Exception) { }
        return out
    }

    private fun saveClips(l: List<String>) = sp.edit().putString("clips", JSONArray(l).toString()).apply()

    fun addClip(t: String) {
        val l = clips()
        l.remove(t)
        l.add(0, t)
        saveClips(l.take(30))
    }

    fun clearClips() = saveClips(emptyList())

    // Teks cepat (snippet)
    fun snippets(): MutableList<Snippet> {
        val out = mutableListOf<Snippet>()
        try {
            val a = JSONArray(sp.getString("snippets", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Snippet(o.getString("t"), o.getString("v")))
            }
        } catch (e: Exception) { }
        return out
    }

    private fun saveSnippets(l: List<Snippet>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("t", it.title).put("v", it.text)) }
        sp.edit().putString("snippets", a.toString()).apply()
    }

    fun addSnippet(title: String, text: String) {
        val l = snippets()
        l.add(Snippet(title, text))
        saveSnippets(l.take(50))
    }

    fun removeSnippet(index: Int) {
        val l = snippets()
        if (index in l.indices) {
            l.removeAt(index)
            saveSnippets(l)
        }
    }

    fun clearSnippets() = sp.edit().remove("snippets").apply()

    // Learned words
    fun learned(): Set<String> = sp.getStringSet("learned", emptySet()) ?: emptySet()

    fun addLearned(w: String) {
        val s = HashSet(learned())
        s.add(w)
        if (s.size > 800) s.remove(s.first())
        sp.edit().putStringSet("learned", s).apply()
    }
}
