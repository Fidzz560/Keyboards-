package com.example.mykeyboard

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var st1: TextView
    private lateinit var st2: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(20), dp(16), dp(28))
        val sc = ScrollView(this)
        sc.setBackgroundColor(Ui.BG)
        sc.addView(col)
        setContentView(sc)

        col.addView(buildHeader())

        col.addView(sectionTitle("Mulai dalam 2 langkah"))
        st1 = statusText()
        col.addView(stepCard(
            1, "Aktifkan My Keyboard", "Nyalakan My Keyboard di daftar keyboard Android.",
            st1, "Buka pengaturan keyboard"
        ) { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) })
        st2 = statusText()
        col.addView(stepCard(
            2, "Pilih sebagai keyboard", "Pilih My Keyboard sebagai keyboard yang sedang dipakai.",
            st2, "Pilih keyboard"
        ) { (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker() })

        val test = EditText(this)
        test.hint = "Coba ketik di sini..."
        test.setTextColor(Ui.TEXT)
        test.setHintTextColor(Ui.MUTED)
        test.setPadding(dp(16), dp(14), dp(16), dp(14))
        test.background = roundRect(Ui.CARD, 16, Ui.STROKE, 1)
        val tlp = LinearLayout.LayoutParams(-1, -2)
        tlp.topMargin = dp(12)
        test.layoutParams = tlp
        col.addView(test)

        col.addView(sectionTitle("Menu"))
        val tiles = listOf(
            menuTile(Ic.PALETTE, "Tema & Warna", "${Themes.list.size} preset + warna kustom") { open(ThemeActivity::class.java) },
            menuTile(Ic.IMAGE, "Latar Foto/Video", "Video diputar berulang") { open(BackgroundActivity::class.java) },
            menuTile(Ic.BOLT, "Teks Cepat", "Simpan kalimat yang sering diketik") { open(SnippetsActivity::class.java) },
            menuTile(Ic.FLOAT, "Mengambang", "Mengambang dan satu tangan") { page("float") },
            menuTile(Ic.GRID, "Tampilan & Ukuran", "Tinggi, huruf, susunan") { page("layout") },
            menuTile(Ic.KEYBOARD, "Fitur Mengetik", "Saran kata, geser spasi") { page("behavior") },
            menuTile(Ic.VIBRATE, "Getar & Suara", "Umpan balik saat mengetik") { page("feedback") },
            menuTile(Ic.TRASH, "Data & Reset", "Hapus riwayat, reset") { page("data") }
        )
        tiles.chunked(2).forEach { pair ->
            col.addView(LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                pair.forEach { addView(it) }
            })
        }

        col.addView(sectionTitle("Fitur di keyboard"))
        val features = cardBox()
        features.addView(tv(
            "Emoji, riwayat clipboard, edit teks (kursor, pilih, salin, tempel), ketik suara, " +
                "mode mengambang, satu tangan, saran kata, geser spasi untuk memindah kursor, " +
                "pratinjau tombol, dan teks cepat. Semua bisa diatur lewat menu ikon di bar atas keyboard.",
            13f, Ui.MUTED
        ))
        col.addView(features)

        val foot = LinearLayout(this)
        foot.orientation = LinearLayout.VERTICAL
        foot.gravity = Gravity.CENTER_HORIZONTAL
        foot.setPadding(0, dp(28), 0, 0)
        foot.addView(tv("My Keyboard v3.0", 12f, Ui.MUTED).apply { gravity = Gravity.CENTER })
        foot.addView(tv("By Fidzz", 14f, Ui.ACCENT, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(2), 0, 0)
        })
        col.addView(foot)

        // Elemen tampil bertahap dari atas ke bawah
        for (i in 0 until col.childCount) col.getChildAt(i).enterAnim(i * 45L)

        val p = Prefs(this)
        if (savedInstanceState == null && !p.sp.getBoolean("app_welcomed", false)) {
            p.sp.edit().putBoolean("app_welcomed", true).apply()
            AlertDialog.Builder(this)
                .setTitle("Selamat Datang Di My Keyboard")
                .setMessage("Ikuti 2 langkah di layar: aktifkan keyboard, lalu pilih sebagai keyboard utama. Setelah itu atur tema, warna, dan latar sesukamu.")
                .setPositiveButton("Mulai", null)
                .show()
        }
    }

    override fun onResume() {
        super.onResume()
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        val enabled = imm.enabledInputMethodList.any { it.packageName == packageName }
        val cur = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
            ?.startsWith("$packageName/") == true
        setStatus(st1, enabled, if (enabled) "Sudah aktif" else "Belum aktif")
        setStatus(st2, cur, if (cur) "Sedang dipakai" else "Belum dipilih")
    }

    private fun setStatus(v: TextView, ok: Boolean, msg: String) {
        v.text = "● $msg"
        v.setTextColor(if (ok) Ui.OK else Ui.BAD)
    }

    private fun open(c: Class<*>) = startActivity(Intent(this, c))

    private fun page(name: String) =
        startActivity(Intent(this, SettingsActivity::class.java).putExtra(SettingsActivity.EXTRA_PAGE, name))

    private fun statusText(): TextView = tv("", 13f, Ui.MUTED)

    private fun buildHeader(): View {
        val head = LinearLayout(this)
        head.orientation = LinearLayout.VERTICAL
        head.setPadding(dp(20), dp(22), dp(20), dp(22))
        val g = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.parseColor("#3B5BDB"), Color.parseColor("#7048E8"))
        )
        g.cornerRadius = dp(22).toFloat()
        head.background = g

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.addView(iconBadge(Ic.KEYBOARD, Color.WHITE, Color.parseColor("#33FFFFFF"), 52))
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        titles.layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(14) }
        titles.addView(tv("My Keyboard", 22f, Color.WHITE, true))
        titles.addView(tv("By Fidzz", 13f, Color.parseColor("#E5E9FF")))
        top.addView(titles)
        head.addView(top)

        head.addView(tv(
            "Keyboard buatanmu sendiri: atur tema, latar video, teks cepat, mode mengambang, dan banyak lagi.",
            14f, Color.parseColor("#E5E9FF")
        ).apply { setPadding(0, dp(16), 0, 0) })
        return head
    }

    private fun stepCard(
        num: Int, title: String, desc: String, status: TextView, btn: String, onClick: () -> Unit
    ): View {
        val box = cardBox()
        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        val badge = tv("$num", 14f, Color.parseColor("#0B1B3A"), true)
        badge.gravity = Gravity.CENTER
        badge.background = roundRect(Ui.ACCENT, 14)
        badge.layoutParams = LinearLayout.LayoutParams(dp(28), dp(28))
        top.addView(badge)
        val heading = tv(title, 16f, Ui.TEXT, true)
        heading.layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(10) }
        top.addView(heading)
        box.addView(top)
        box.addView(tv(desc, 13f, Ui.MUTED).apply { setPadding(0, dp(8), 0, 0) })
        status.setPadding(0, dp(8), 0, 0)
        box.addView(status)
        box.addView(actionButton(btn, onClick))
        return box
    }

    private fun menuTile(ic: Ic, name: String, sub: String, onClick: () -> Unit): View {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(14), dp(14), dp(14), dp(14))
        c.background = roundRect(Ui.CARD, 18, Ui.STROKE, 1)
        val lp = LinearLayout.LayoutParams(0, -2, 1f)
        lp.setMargins(dp(5), dp(5), dp(5), dp(5))
        c.layoutParams = lp
        c.addView(iconBadge(ic, Ui.ACCENT, Color.parseColor("#26344F"), 40))
        c.addView(tv(name, 15f, Ui.TEXT, true).apply { setPadding(0, dp(12), 0, dp(2)) })
        c.addView(tv(sub, 12f, Ui.MUTED))
        c.bounce()
        c.setOnClickListener { onClick() }
        return c
    }
}
