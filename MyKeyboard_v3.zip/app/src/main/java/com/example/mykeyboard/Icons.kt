package com.example.mykeyboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import kotlin.math.min

/** Ikon garis buatan sendiri (tanpa emoji). Semua digambar di kotak 24 x 24 satuan. */
enum class Ic {
    EMOJI, CLIP, MIC, SLIDERS, GLOBE, BACKSPACE, BACK, PALETTE, IMAGE, FLOAT,
    GRID, KEYBOARD, VIBRATE, TRASH, BOLT, PLUS, SHIFT, SHIFT_ON, CAPS
}

object Icons {
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = 1.9f
    }
    private val solid = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val box = RectF()
    private val path = Path()

    /** Gambar ikon [ic] di posisi (x, y) dengan ukuran [size] piksel. */
    fun draw(c: Canvas, ic: Ic, x: Float, y: Float, size: Float, color: Int) {
        line.color = color
        solid.color = color
        c.save()
        c.translate(x, y)
        val k = size / 24f
        c.scale(k, k)
        when (ic) {
            Ic.EMOJI -> {
                c.drawCircle(12f, 12f, 9.5f, line)
                c.drawCircle(9f, 10f, 1.3f, solid)
                c.drawCircle(15f, 10f, 1.3f, solid)
                path.reset()
                path.moveTo(8.5f, 14f)
                path.quadTo(12f, 17.5f, 15.5f, 14f)
                c.drawPath(path, line)
            }
            Ic.CLIP -> {
                box.set(5f, 4f, 19f, 21f)
                c.drawRoundRect(box, 2.5f, 2.5f, line)
                box.set(9f, 2f, 15f, 6.5f)
                c.drawRoundRect(box, 1.2f, 1.2f, line)
                c.drawLine(9f, 11f, 15f, 11f, line)
                c.drawLine(9f, 15f, 15f, 15f, line)
                c.drawLine(9f, 19f, 12.5f, 19f, line)
            }
            Ic.MIC -> {
                box.set(8.5f, 2.5f, 15.5f, 14.5f)
                c.drawRoundRect(box, 3.5f, 3.5f, line)
                box.set(5.5f, 8f, 18.5f, 20f)
                c.drawArc(box, 0f, 180f, false, line)
                c.drawLine(12f, 20f, 12f, 22.5f, line)
                c.drawLine(8.5f, 22.5f, 15.5f, 22.5f, line)
            }
            Ic.SLIDERS -> {
                c.drawLine(4f, 7f, 20f, 7f, line)
                c.drawLine(4f, 12f, 20f, 12f, line)
                c.drawLine(4f, 17f, 20f, 17f, line)
                c.drawCircle(15f, 7f, 2.6f, solid)
                c.drawCircle(9f, 12f, 2.6f, solid)
                c.drawCircle(16f, 17f, 2.6f, solid)
            }
            Ic.GLOBE -> {
                c.drawCircle(12f, 12f, 9.5f, line)
                box.set(7.5f, 2.5f, 16.5f, 21.5f)
                c.drawOval(box, line)
                c.drawLine(2.5f, 12f, 21.5f, 12f, line)
            }
            Ic.BACKSPACE -> {
                path.reset()
                path.moveTo(9f, 5f)
                path.lineTo(20.5f, 5f)
                path.lineTo(20.5f, 19f)
                path.lineTo(9f, 19f)
                path.lineTo(3f, 12f)
                path.close()
                c.drawPath(path, line)
                c.drawLine(13f, 9.5f, 17f, 14.5f, line)
                c.drawLine(17f, 9.5f, 13f, 14.5f, line)
            }
            Ic.BACK -> {
                path.reset()
                path.moveTo(15f, 5f)
                path.lineTo(8f, 12f)
                path.lineTo(15f, 19f)
                c.drawPath(path, line)
            }
            Ic.PALETTE -> {
                c.drawCircle(12f, 12f, 9.5f, line)
                c.drawCircle(8f, 10f, 1.5f, solid)
                c.drawCircle(12f, 7f, 1.5f, solid)
                c.drawCircle(16f, 10f, 1.5f, solid)
                c.drawCircle(9.5f, 15f, 1.5f, solid)
            }
            Ic.IMAGE -> {
                box.set(2.5f, 4.5f, 21.5f, 19.5f)
                c.drawRoundRect(box, 3f, 3f, line)
                path.reset()
                path.moveTo(4f, 17f)
                path.lineTo(9f, 11.5f)
                path.lineTo(13f, 15.5f)
                path.lineTo(15.5f, 13f)
                path.lineTo(20f, 17f)
                c.drawPath(path, line)
                c.drawCircle(16.5f, 9f, 1.6f, solid)
            }
            Ic.FLOAT -> {
                box.set(2.5f, 2.5f, 15.5f, 13.5f)
                c.drawRoundRect(box, 2f, 2f, line)
                box.set(8.5f, 10.5f, 21.5f, 21.5f)
                c.drawRoundRect(box, 2f, 2f, line)
            }
            Ic.GRID -> {
                box.set(3f, 3f, 10f, 10f)
                c.drawRoundRect(box, 1.5f, 1.5f, line)
                box.set(14f, 3f, 21f, 10f)
                c.drawRoundRect(box, 1.5f, 1.5f, line)
                box.set(3f, 14f, 10f, 21f)
                c.drawRoundRect(box, 1.5f, 1.5f, line)
                box.set(14f, 14f, 21f, 21f)
                c.drawRoundRect(box, 1.5f, 1.5f, line)
            }
            Ic.KEYBOARD -> {
                box.set(2f, 5.5f, 22f, 18.5f)
                c.drawRoundRect(box, 3f, 3f, line)
                c.drawCircle(6f, 9.5f, 0.95f, solid)
                c.drawCircle(10f, 9.5f, 0.95f, solid)
                c.drawCircle(14f, 9.5f, 0.95f, solid)
                c.drawCircle(18f, 9.5f, 0.95f, solid)
                c.drawLine(7f, 14.5f, 17f, 14.5f, line)
            }
            Ic.VIBRATE -> {
                box.set(7.5f, 2.5f, 16.5f, 21.5f)
                c.drawRoundRect(box, 2.5f, 2.5f, line)
                c.drawLine(3f, 8.5f, 3f, 15.5f, line)
                c.drawLine(21f, 8.5f, 21f, 15.5f, line)
            }
            Ic.TRASH -> {
                c.drawLine(4f, 6f, 20f, 6f, line)
                path.reset()
                path.moveTo(9f, 6f)
                path.lineTo(9f, 3.5f)
                path.lineTo(15f, 3.5f)
                path.lineTo(15f, 6f)
                c.drawPath(path, line)
                path.reset()
                path.moveTo(6f, 6f)
                path.lineTo(7f, 20.5f)
                path.lineTo(17f, 20.5f)
                path.lineTo(18f, 6f)
                c.drawPath(path, line)
                c.drawLine(10f, 10f, 10f, 16.5f, line)
                c.drawLine(14f, 10f, 14f, 16.5f, line)
            }
            Ic.BOLT -> {
                path.reset()
                path.moveTo(13.5f, 2f)
                path.lineTo(4.5f, 13.5f)
                path.lineTo(11f, 13.5f)
                path.lineTo(10f, 22f)
                path.lineTo(19.5f, 10f)
                path.lineTo(13f, 10f)
                path.close()
                c.drawPath(path, solid)
            }
            Ic.PLUS -> {
                c.drawLine(12f, 5f, 12f, 19f, line)
                c.drawLine(5f, 12f, 19f, 12f, line)
            }
            Ic.SHIFT -> arrow(c, false)
            Ic.SHIFT_ON -> arrow(c, true)
            Ic.CAPS -> {
                arrow(c, true)
                c.drawLine(7f, 22.5f, 17f, 22.5f, line)
            }
        }
        c.restore()
    }

    private fun arrow(c: Canvas, filled: Boolean) {
        path.reset()
        path.moveTo(12f, 3f)
        path.lineTo(21f, 12f)
        path.lineTo(16f, 12f)
        path.lineTo(16f, 20.5f)
        path.lineTo(8f, 20.5f)
        path.lineTo(8f, 12f)
        path.lineTo(3f, 12f)
        path.close()
        c.drawPath(path, if (filled) solid else line)
    }
}

/** Tampilan ikon untuk bar keyboard, kartu menu, dan daftar. */
class IconView(ctx: Context, private val ic: Ic, private var color: Int) : View(ctx) {
    var fraction = 0.6f

    override fun onDraw(c: Canvas) {
        val size = min(width, height) * fraction
        Icons.draw(c, ic, (width - size) / 2f, (height - size) / 2f, size, color)
    }

    fun tint(col: Int) {
        color = col
        invalidate()
    }
}
