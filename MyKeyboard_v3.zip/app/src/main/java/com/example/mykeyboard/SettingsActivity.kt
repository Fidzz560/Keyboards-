package com.example.mykeyboard

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat

/** Halaman pengaturan per kategori (lihat EXTRA_PAGE). */
class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val page = intent.getStringExtra(EXTRA_PAGE) ?: "layout"
        title = TITLES[page] ?: "Pengaturan"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        if (savedInstanceState == null) {
            val f = PrefsFragment()
            f.arguments = Bundle().apply { putString("page", page) }
            supportFragmentManager.beginTransaction().replace(android.R.id.content, f).commit()
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    class PrefsFragment : PreferenceFragmentCompat() {
        override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
            val res = when (arguments?.getString("page")) {
                "float" -> R.xml.pref_float
                "behavior" -> R.xml.pref_behavior
                "feedback" -> R.xml.pref_feedback
                "data" -> R.xml.pref_data
                else -> R.xml.pref_layout
            }
            setPreferencesFromResource(res, rootKey)
            val p = Prefs(requireContext())
            fun act(key: String, msg: String, block: () -> Unit) {
                findPreference<Preference>(key)?.setOnPreferenceClickListener {
                    block()
                    Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show()
                    true
                }
            }
            act("clear_learned", "Kata yang dipelajari dihapus") { p.sp.edit().remove("learned").apply() }
            act("clear_clips", "Riwayat clipboard dihapus") { p.clearClips() }
            act("clear_snippets", "Teks cepat dihapus") { p.clearSnippets() }
            act("reset", "Pengaturan direset") {
                p.sp.edit().clear().apply()
                requireActivity().recreate()
            }
            act("float_reset", "Posisi dikembalikan") {
                p.sp.edit().remove("float_x").remove("float_y").apply()
            }
        }
    }

    companion object {
        const val EXTRA_PAGE = "page"
        private val TITLES = mapOf(
            "float" to "Mengambang & Satu Tangan",
            "layout" to "Tampilan & Ukuran",
            "behavior" to "Fitur Mengetik",
            "feedback" to "Getar & Suara",
            "data" to "Data & Reset"
        )
    }
}
