package com.example.mykeyboard

import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import androidx.appcompat.app.AppCompatActivity

class ThemeActivity : AppCompatActivity() {
    private lateinit var p: Prefs
    private lateinit var big: ThemePreview
    private lateinit var grid: LinearLayout
    private lateinit var colors: LinearLayout

    private val colorKeys = listOf(
        Triple("color_bg", "Latar keyboard", "#202124"),
        Triple("color_key", "Tombol huruf", "#3C4043"),
        Triple("color_func", "Tombol fungsi", "#2D2F31"),
        Triple("color_text", "Warna teks", "#FFFFFF"),
        Triple("color_accent", "Warna aksen (Enter, Caps)", "#8AB4F8")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        p = Prefs(this)
        val sc = ScrollView(this)
        sc.setBackgroundColor(Ui.BG)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(12), dp(16), dp(28))
        sc.addView(col)
        setContentView(sc)

        big = ThemePreview(this)
        big.layoutParams = LinearLayout.LayoutParams(-1, dp(150))
        col.addView(big)

        col.addView(sectionTitle("Preset tema"))
        grid = LinearLayout(this)
        grid.orientation = LinearLayout.VERTICAL
        col.addView(grid)

        col.addView(sectionTitle("Warna kustom"))
        val box = cardBox()
        box.addView(tv("Ketuk warna untuk mengubah. Tema otomatis pindah ke Kustom.", 12f, Ui.MUTED))
        colors = LinearLayout(this)
        colors.orientation = LinearLayout.VERTICAL
        box.addView(colors)
        box.addView(actionButton("Salin warna tema saat ini ke Kustom") {
            val pal = p.palette()
            p.sp.edit()
                .putString("color_bg", hex(pal.bg)).putString("color_key", hex(pal.key))
                .putString("color_func", hex(pal.func)).putString("color_text", hex(pal.text))
                .putString("color_accent", hex(pal.accent)).putString("theme", "custom").apply()
            refresh()
        })
        col.addView(box)

        col.addView(sectionTitle("Bentuk tombol"))
        val shape = cardBox()
        shape.addView(sliderRow("Kelengkungan sudut", p.sp, "radius", 0, 30, 10) { refresh() })
        shape.addView(sliderRow("Jarak antar tombol", p.sp, "gap", 0, 12, 3) { refresh() })
        col.addView(shape)
        refresh()
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    private fun refresh() {
        big.animatePal(p.palette())
        big.radiusDp = p.radius.toFloat()
        big.gapDp = p.gap.toFloat()
        big.invalidate()
        renderGrid()
        renderColors()
    }

    private fun renderGrid() {
        grid.removeAllViews()
        val items = Themes.list.map { Triple(it.id, it.name, it.pal) } + Triple("custom", "Kustom", p.custom())
        items.chunked(3).forEach { chunk ->
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            for (i in 0 until 3) {
                val it = chunk.getOrNull(i)
                if (it == null) {
                    r.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(0, 1, 1f) })
                    continue
                }
                val cell = LinearLayout(this)
                cell.orientation = LinearLayout.VERTICAL
                cell.setPadding(dp(4), dp(4), dp(4), dp(4))
                val sel = p.theme == it.first
                cell.background = roundRect(Ui.BG, 12, Ui.ACCENT, if (sel) 2 else 0)
                val lp = LinearLayout.LayoutParams(0, -2, 1f)
                lp.setMargins(dp(3), dp(3), dp(3), dp(3))
                cell.layoutParams = lp
                val pv = ThemePreview(this)
                pv.pal = it.third
                pv.radiusDp = p.radius.toFloat()
                pv.gapDp = p.gap.toFloat()
                pv.layoutParams = LinearLayout.LayoutParams(-1, dp(70))
                cell.addView(pv)
                val name = tv(it.second, 12f, if (sel) Ui.ACCENT else Ui.TEXT, sel)
                name.gravity = android.view.Gravity.CENTER
                name.setPadding(0, dp(4), 0, 0)
                cell.addView(name)
                cell.setOnClickListener {_ ->
                    p.sp.edit().putString("theme", it.first).apply()
                    refresh()
                }
                r.addView(cell)
            }
            grid.addView(r)
        }
    }

    private fun renderColors() {
        colors.removeAllViews()
        val cur = p.custom()
        val vals = listOf(cur.bg, cur.key, cur.func, cur.text, cur.accent)
        colorKeys.forEachIndexed { i, (key, name, def) ->
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = android.view.Gravity.CENTER_VERTICAL
            row.setPadding(0, dp(8), 0, dp(8))
            val l = tv(name, 14f)
            l.layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            val code = tv(hex(vals[i]), 12f, Ui.MUTED)
            code.setPadding(0, 0, dp(10), 0)
            val sw = View(this)
            sw.layoutParams = LinearLayout.LayoutParams(dp(40), dp(28))
            sw.background = roundRect(vals[i], 8, Ui.MUTED, 1)
            row.addView(l)
            row.addView(code)
            row.addView(sw)
            row.setOnClickListener {
                pickColor(name, p.color(key, def)) { c ->
                    p.sp.edit().putString(key, hex(c)).putString("theme", "custom").apply()
                    refresh()
                }
            }
            colors.addView(row)
        }
    }
}
